from datetime import timedelta
from django.contrib import messages
from django.contrib.auth import login as auth_login, logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.db import transaction
from django.db.models import Count, Q
from django.db.models.functions import TruncDate
from django.http import HttpResponseBadRequest, HttpResponseForbidden
from django.shortcuts import get_object_or_404, redirect, render
from django.utils import timezone
from django.utils.text import slugify
from django.views.decorators.http import require_POST
from django.core.paginator import Paginator

from .decorators import customer_required, dispatcher_or_superadmin, superadmin_required, worker_required
from .forms import (PhoneLoginForm, CustomerRegistrationForm, ApplicationForm, StaffCreateForm, StaffEditForm, PasswordResetForm, DispatcherNoteForm, ResolutionForm, SystemRuleForm, WorkerCompletionForm, CustomerApprovalForm, CustomerCorrectionForm)
from .models import User, Application, ApplicationEvent, EquipmentType, Department, Notification, SystemRule, PriceListCategory, PriceListItem, ApplicationWork


@require_POST
def logout_view(request):
    auth_logout(request)
    return redirect("core:login")


def login_view(request):
    if request.user.is_authenticated: return redirect("core:dashboard")
    form = PhoneLoginForm(request, data=request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.get_user()
        if not user.is_active: form.add_error(None, "This account is blocked. Contact an administrator.")
        else:
            auth_login(request, user); return redirect("core:dashboard")
    return render(request, "core/login.html", {"form": form})


def customer_register(request):
    if request.user.is_authenticated: return redirect("core:dashboard")
    form = CustomerRegistrationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        user = form.save(); auth_login(request, user); return redirect("core:customer_dashboard")
    return render(request, "core/register.html", {"form": form})


@login_required
def dashboard(request):
    return redirect({
        User.CUSTOMER: "core:customer_dashboard", User.WORKER: "core:worker_dashboard",
        User.DISPATCHER: "core:dispatcher_dashboard", User.SUPERADMIN: "core:superadmin_dashboard",
    }.get(request.user.role, "core:login"))


def _form_errors(form):
    return " ".join(str(error) for errors in form.errors.values() for error in errors)


def _notify(user, title, body="", application=None):
    Notification.objects.create(user=user, title=title, body=body, application=application)


def _log(app, actor, event, notes=""):
    ApplicationEvent.objects.create(application=app, actor=actor, event_type=event, notes=notes)


@customer_required
def customer_dashboard(request):
    form = ApplicationForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            app = form.save(commit=False)
            app.customer = request.user
            app.save()
            # Compatibility with the previous many-to-many schema.
            app.equipment_types.set([app.equipment_type])
            _log(app, request.user, ApplicationEvent.CREATED, f"Submitted for {app.equipment_type.name}")
            for dispatcher in User.objects.filter(role=User.DISPATCHER, is_active=True):
                _notify(dispatcher, f"New {app.equipment_type.name} request", f"Request #{app.pk} is waiting for dispatch.", app)
            workers = User.objects.filter(role=User.WORKER, is_active=True, specializations=app.equipment_type).distinct()
            for worker in workers:
                _notify(worker, f"New {app.equipment_type.name} request", f"Request #{app.pk} is open. Take it yourself or wait for dispatch.", app)
        messages.success(request, f"Request #{app.pk} submitted. Dispatch will assign a technician, or a technician may take it.")
        return redirect("core:customer_dashboard")
    qs = (Application.objects.filter(customer=request.user)
          .select_related("department", "equipment_type", "assigned_worker", "customer_approved_by")
          .prefetch_related("completed_works"))
    page = Paginator(qs, 10).get_page(request.GET.get("page"))
    return render(request, "core/customer_dashboard.html", {"form": form, "applications": page, "page_obj": page})


@worker_required
def worker_dashboard(request):
    worker = request.user
    base = Application.objects.filter(assigned_worker=worker).select_related("department", "equipment_type", "customer")
    active = base.exclude(status=Application.DONE)
    history = base.filter(status=Application.DONE)
    history_page = Paginator(history, 12).get_page(request.GET.get("page"))

    now = timezone.now(); start = now - timedelta(days=30)
    daily = base.filter(status=Application.DONE, completed_at__gte=start, completed_at__isnull=False).annotate(day=TruncDate("completed_at")).values("day").annotate(total=Count("id"))
    daily_map = {x["day"].isoformat(): x["total"] for x in daily}
    chart = []
    for i in range(13, -1, -1):
        d = timezone.localdate() - timedelta(days=i); chart.append({"label": d.strftime("%d %b"), "value": daily_map.get(d.isoformat(), 0)})
    max_value = max((x["value"] for x in chart), default=0)
    # Keep empty charts useful and, importantly, never divide by zero.
    chart_scale = max_value or 1
    for x in chart:
        x["height"] = max(8, round(x["value"] / chart_scale * 100)) if x["value"] else 8

    available = (Application.objects.filter(status=Application.SUBMITTED, assigned_worker__isnull=True,
                                            equipment_type__in=worker.specializations.filter(active=True))
                 .select_related("department", "equipment_type").order_by("-is_urgent", "created_at"))

    # Requests in the worker's own categories that colleagues are already handling (read-only).
    team = (Application.objects.filter(equipment_type__in=worker.specializations.filter(active=True))
            .exclude(status__in=[Application.SUBMITTED, Application.DONE]).exclude(assigned_worker=worker)
            .select_related("department", "equipment_type", "assigned_worker").order_by("-updated_at")[:20])

    completed = base.filter(status=Application.DONE).count()
    in_progress = base.filter(status=Application.IN_PROGRESS).count()
    today = timezone.localdate()
    period_stats = {
        "today": base.filter(status=Application.DONE, completed_at__date=today).count(),
        "yesterday": base.filter(status=Application.DONE, completed_at__date=today - timedelta(days=1)).count(),
        "week": base.filter(status=Application.DONE, completed_at__gte=now - timedelta(days=7)).count(),
        "month": base.filter(status=Application.DONE, completed_at__gte=now - timedelta(days=30)).count(),
    }
    return render(request, "core/worker_dashboard.html", {
        "worker": worker, "active_apps": active.order_by("-is_urgent", "created_at"), "history": history_page,
        "available_apps": available, "team_apps": team, "active_count": active.count(), "completed_count": completed, "in_progress": in_progress,
        "chart": chart, "max_chart": max_value, "period_stats": period_stats, "page_obj": history_page,
    })


@worker_required
@require_POST
def worker_start(request, pk):
    with transaction.atomic():
        app = get_object_or_404(Application.objects.select_for_update().select_related("equipment_type"), pk=pk)
        if app.assigned_worker_id != request.user.id: return HttpResponseForbidden("This request is not assigned to you.")
        if app.status != Application.ASSIGNED: return HttpResponseBadRequest("Only assigned requests can be started.")
        if not request.user.specializations.filter(pk=app.equipment_type_id, active=True).exists(): return HttpResponseForbidden("You are not certified for this repair type.")
        now = timezone.now(); app.status = Application.IN_PROGRESS; app.started_at = now; app.save(update_fields=["status", "started_at", "updated_at"])
        _log(app, request.user, ApplicationEvent.STARTED)
        _notify(app.customer, f"Request #{app.pk} started", f"{request.user.display_name} is now working on your request.", app)
    return redirect("core:worker_dashboard")


@worker_required
@require_POST
def worker_claim(request, pk):
    """A technician takes an open request that matches their specialization and starts it."""
    with transaction.atomic():
        app = get_object_or_404(Application.objects.select_for_update().select_related("equipment_type", "customer"), pk=pk)
        if app.status != Application.SUBMITTED or app.assigned_worker_id:
            messages.error(request, f"Request #{app.pk} was already taken by another technician.")
            return redirect("core:worker_dashboard")
        if not request.user.specializations.filter(pk=app.equipment_type_id, active=True).exists():
            return HttpResponseForbidden("You are not certified for this repair type.")
        now = timezone.now()
        app.assigned_worker = request.user; app.assigned_at = now; app.started_at = now; app.status = Application.IN_PROGRESS
        app.save(update_fields=["assigned_worker", "assigned_at", "started_at", "status", "updated_at"])
        _log(app, request.user, ApplicationEvent.ASSIGNED, f"Taken by {request.user.display_name}")
        _log(app, request.user, ApplicationEvent.STARTED)
        _notify(app.customer, f"Request #{app.pk} started", f"{request.user.display_name} took your request and is working on it.", app)
    messages.success(request, f"You took request #{pk}.")
    return redirect("core:worker_dashboard")


@worker_required
@require_POST
def worker_resume_correction(request, pk):
    with transaction.atomic():
        app = get_object_or_404(Application.objects.select_for_update(), pk=pk)
        if app.assigned_worker_id != request.user.id:
            return HttpResponseForbidden("You can only resume your own assignments.")
        if app.status != Application.CORRECTION_REQUIRED:
            return HttpResponseBadRequest("This request is not waiting for correction.")
        app.status = Application.IN_PROGRESS
        app.save(update_fields=["status", "updated_at"])
        _log(app, request.user, ApplicationEvent.STARTED, "Repair resumed after customer correction request.")
    return redirect("core:worker_dashboard")


@worker_required
def worker_complete(request, pk):
    app = get_object_or_404(
        Application.objects.select_related("customer", "department", "equipment_type").prefetch_related("completed_works"),
        pk=pk, assigned_worker=request.user
    )
    if app.status not in {Application.IN_PROGRESS, Application.CORRECTION_REQUIRED}:
        return HttpResponseBadRequest("Only an active repair can be submitted for approval.")
    form = WorkerCompletionForm(request.POST or None, request.FILES or None)
    selected_work_ids = {str(value) for value in request.POST.getlist("works")}
    if request.method == "POST":
        selected_quantities = {
            code: request.POST.get(f"qty_{code}", "1")
            for code in selected_work_ids
        }
    else:
        selected_quantities = {
            str(work.price_list_item_id): work.quantity
            for work in app.completed_works.all()
        }
    if request.method == "POST" and form.is_valid():
        with transaction.atomic():
            locked = get_object_or_404(Application.objects.select_for_update(), pk=pk, assigned_worker=request.user)
            if locked.status not in {Application.IN_PROGRESS, Application.CORRECTION_REQUIRED}:
                return HttpResponseBadRequest("This request was already submitted.")
            locked.completed_works.all().delete()
            quantities = form.cleaned_data["quantities"]
            for item in form.cleaned_data["works"]:
                ApplicationWork.objects.create(
                    application=locked,
                    price_list_item=item,
                    quantity=quantities[item.pk],
                    price_snapshot=item.price,
                    name_snapshot_en=item.name_en,
                    name_snapshot_uz=item.name_uz,
                    name_snapshot_uz_cyrl=item.name_uz_cyrl,
                    name_snapshot_ru=item.name_ru,
                )
            locked.resolution_notes = form.cleaned_data["resolution_notes"]
            locked.completion_photo = form.cleaned_data["completion_photo"]
            locked.completion_submitted_at = timezone.now()
            locked.completed_at = timezone.now()
            locked.correction_note = ""
            locked.customer_approval_note = ""
            locked.status = Application.WAITING_APPROVAL
            locked.save(update_fields=[
                "resolution_notes", "completion_photo", "completion_submitted_at", "completed_at",
                "correction_note", "customer_approval_note", "status", "updated_at"
            ])
            _log(locked, request.user, ApplicationEvent.COMPLETED, locked.resolution_notes[:500])
            _notify(locked.customer, f"Request #{locked.pk} is ready for approval", "Please review the completed work and photo.", locked)
        messages.success(request, f"Request #{pk} submitted for customer approval.")
        return redirect("core:worker_dashboard")
    return render(request, "core/worker_complete.html", {
        "form": form,
        "application": app,
        "price_list": PriceListItem.objects.filter(active=True).select_related("price_category"),
        "price_categories": PriceListCategory.objects.filter(active=True, items__active=True).distinct(),
        "selected_work_ids": selected_work_ids,
        "selected_quantities": selected_quantities,
    })


@customer_required
@require_POST
def customer_approve(request, pk):
    with transaction.atomic():
        app = get_object_or_404(Application.objects.select_for_update(), pk=pk, customer=request.user)
        if app.status != Application.WAITING_APPROVAL:
            return HttpResponseBadRequest("This request is not waiting for your approval.")
        form = CustomerApprovalForm(request.POST)
        if not form.is_valid():
            return HttpResponseBadRequest("Invalid approval data.")
        app.customer_approval_note = form.cleaned_data["note"]
        app.customer_approved_by = request.user
        app.customer_approved_at = timezone.now()
        app.status = Application.DONE
        app.save(update_fields=["customer_approval_note", "customer_approved_by", "customer_approved_at", "status", "updated_at"])
        _log(app, request.user, ApplicationEvent.COMPLETED, "Customer approved the completed work.")
        if app.assigned_worker_id:
            _notify(app.assigned_worker, f"Request #{app.pk} approved", "The customer approved your completed work.", app)
    messages.success(request, f"Request #{pk} approved. Thank you.")
    return redirect("core:customer_dashboard")


@customer_required
@require_POST
def customer_request_correction(request, pk):
    with transaction.atomic():
        app = get_object_or_404(Application.objects.select_for_update(), pk=pk, customer=request.user)
        if app.status != Application.WAITING_APPROVAL:
            return HttpResponseBadRequest("This request is not waiting for your approval.")
        form = CustomerCorrectionForm(request.POST)
        if not form.is_valid():
            return HttpResponseBadRequest("Please describe what needs correction.")
        app.correction_note = form.cleaned_data["note"]
        app.customer_approval_note = ""
        app.status = Application.CORRECTION_REQUIRED
        app.save(update_fields=["correction_note", "customer_approval_note", "status", "updated_at"])
        _log(app, request.user, ApplicationEvent.NOTE_ADDED, f"Customer requested correction: {app.correction_note[:500]}")
        if app.assigned_worker_id:
            _notify(app.assigned_worker, f"Correction requested for #{app.pk}", app.correction_note[:500], app)
    messages.info(request, f"Your correction request was sent to the technician.")
    return redirect("core:customer_dashboard")


@dispatcher_or_superadmin
def dispatcher_dashboard(request):
    qs = Application.objects.select_related("department", "equipment_type", "assigned_worker", "customer")
    search = request.GET.get("q", "").strip(); status = request.GET.get("status", "active")
    if search: qs = qs.filter(Q(customer_name__icontains=search) | Q(description__icontains=search) | Q(room__icontains=search) | Q(pk__icontains=search))
    if status == "active": qs = qs.exclude(status=Application.DONE)
    elif status in dict(Application.STATUS_CHOICES): qs = qs.filter(status=status)
    apps = Paginator(qs.order_by("-is_urgent", "-created_at"), 18).get_page(request.GET.get("page"))

    workers = list(User.objects.filter(role=User.WORKER, is_active=True).prefetch_related("specializations"))
    active_counts = dict(Application.objects.filter(status__in=[Application.ASSIGNED, Application.IN_PROGRESS], assigned_worker__isnull=False).values("assigned_worker_id").annotate(total=Count("id")).values_list("assigned_worker_id", "total"))
    worker_status = [{"worker": w, "active_count": active_counts.get(w.pk, 0)} for w in workers]
    unassigned = Application.objects.filter(status=Application.SUBMITTED).count()
    urgent = Application.objects.filter(is_urgent=True).exclude(status=Application.DONE).count()
    in_progress = Application.objects.filter(status=Application.IN_PROGRESS).count()
    completed_today = Application.objects.filter(status=Application.DONE, completed_at__date=timezone.localdate()).count()
    return render(request, "core/dispatcher_dashboard.html", {"apps": apps, "page_obj": apps, "worker_status": worker_status, "unassigned": unassigned, "urgent": urgent, "in_progress": in_progress, "completed_today": completed_today, "search": search, "status": status})


@dispatcher_or_superadmin
@require_POST
def assign_worker(request, pk):
    with transaction.atomic():
        app = get_object_or_404(Application.objects.select_for_update().select_related("equipment_type", "customer"), pk=pk)
        if app.status not in (Application.SUBMITTED, Application.ASSIGNED): return HttpResponseBadRequest("This request can no longer be reassigned.")
        worker = get_object_or_404(User, pk=request.POST.get("worker"), role=User.WORKER, is_active=True)
        if not worker.specializations.filter(pk=app.equipment_type_id, active=True).exists(): return HttpResponseForbidden("That worker does not handle this repair category.")
        previous = app.assigned_worker if app.assigned_worker_id and app.assigned_worker_id != worker.pk else None
        if previous:
            _log(app, request.user, ApplicationEvent.UNASSIGNED, f"Unassigned from {previous.display_name}")
            _notify(previous, f"Request #{app.pk} reassigned", "This request was given to another technician.", app)
        now = timezone.now(); app.assigned_worker = worker; app.assigned_by = request.user; app.assigned_at = now; app.status = Application.ASSIGNED; app.save(update_fields=["assigned_worker", "assigned_by", "assigned_at", "status", "updated_at"])
        _log(app, request.user, ApplicationEvent.ASSIGNED, f"Assigned to {worker.display_name}")
        _notify(worker, f"New assignment #{app.pk}", f"{app.equipment_type.name} repair · {app.room}", app)
        _notify(app.customer, f"Request #{app.pk} assigned", f"Technician: {worker.display_name}", app)
    return redirect("core:dispatcher_dashboard")


@dispatcher_or_superadmin
@require_POST
def toggle_priority(request, pk):
    app = get_object_or_404(Application, pk=pk)
    if app.status == Application.DONE: return HttpResponseBadRequest("Completed requests cannot be changed.")
    flag = request.POST.get("flag")
    if flag not in {"urgent", "sensitive"}: return HttpResponseBadRequest("Unknown flag.")
    field = "is_urgent" if flag == "urgent" else "is_sensitive"; new_value = not getattr(app, field)
    setattr(app, field, new_value); app.save(update_fields=[field, "updated_at"])
    _log(app, request.user, ApplicationEvent.MARKED_URGENT if flag == "urgent" else ApplicationEvent.MARKED_SENSITIVE, f"{flag}: {new_value}")
    return redirect("core:dispatcher_dashboard")


@dispatcher_or_superadmin
@require_POST
def dispatcher_note(request, pk):
    app = get_object_or_404(Application, pk=pk)
    form = DispatcherNoteForm(request.POST, instance=app)
    if form.is_valid(): form.save(); _log(app, request.user, ApplicationEvent.NOTE_ADDED, app.dispatcher_notes[:500]); messages.success(request, f"Notes saved for request #{pk}.")
    return redirect("core:dispatcher_dashboard")


@superadmin_required
def superadmin_dashboard(request):
    users = User.objects.exclude(role=User.SUPERADMIN).select_related().prefetch_related("specializations")
    role_filter = request.GET.get("role", "all"); q = request.GET.get("q", "").strip()
    if role_filter in {User.CUSTOMER, User.WORKER, User.DISPATCHER}: users = users.filter(role=role_filter)
    if q: users = users.filter(Q(full_name__icontains=q) | Q(phone_number__icontains=q))
    users_page = Paginator(users.order_by("-date_joined"), 20).get_page(request.GET.get("page"))
    stats = {
        "total_users": User.objects.exclude(role=User.SUPERADMIN).count(), "workers": User.objects.filter(role=User.WORKER, is_active=True).count(),
        "customers": User.objects.filter(role=User.CUSTOMER).count(), "dispatchers": User.objects.filter(role=User.DISPATCHER, is_active=True).count(),
        "open": Application.objects.exclude(status=Application.DONE).count(), "completed": Application.objects.filter(status=Application.DONE).count(),
        "waiting_approval": Application.objects.filter(status=Application.WAITING_APPROVAL).count(),
        "urgent": Application.objects.filter(is_urgent=True).exclude(status=Application.DONE).count(), "today": Application.objects.filter(created_at__date=timezone.localdate()).count(),
    }
    recent = ApplicationEvent.objects.select_related("application", "actor").order_by("-created_at")[:12]
    worker_load = Application.objects.filter(status__in=[Application.ASSIGNED, Application.IN_PROGRESS], assigned_worker__isnull=False).values("assigned_worker_id", "assigned_worker__full_name").annotate(total=Count("id")).order_by("-total")[:8]
    rules = SystemRule.objects.all()
    recent_reports = (Application.objects.select_related("customer", "department", "equipment_type", "assigned_worker")
                      .prefetch_related("completed_works")
                      .exclude(completed_works__isnull=True)
                      .distinct().order_by("-completion_submitted_at")[:12])
    return render(request, "core/superadmin_dashboard.html", {
        "users": users_page, "page_obj": users_page, "stats": stats, "recent": recent,
        "worker_load": worker_load, "rules": rules, "role_filter": role_filter, "q": q, "recent_reports": recent_reports
    })


@superadmin_required
def superadmin_application_detail(request, pk):
    app = get_object_or_404(
        Application.objects.select_related("customer", "assigned_worker", "assigned_by", "department", "equipment_type", "customer_approved_by")
        .prefetch_related("completed_works__price_list_item", "events__actor"), pk=pk
    )
    total = sum((work.total_price for work in app.completed_works.all()), 0)
    return render(request, "core/superadmin_application_detail.html", {"application": app, "total_price": total})


@superadmin_required
def superadmin_user_create(request):
    form = StaffCreateForm(request.POST or None)
    if request.method == "POST" and form.is_valid(): form.save(); messages.success(request, "Staff account created."); return redirect("core:superadmin_dashboard")
    return render(request, "core/superadmin_user_form.html", {"form": form, "mode": "create"})


@superadmin_required
def superadmin_user_edit(request, pk):
    user = get_object_or_404(User, pk=pk)
    if user.is_superadmin: return HttpResponseForbidden("Super admin accounts cannot be edited here.")
    form = StaffEditForm(request.POST or None, instance=user)
    if request.method == "POST" and form.is_valid(): form.save(); messages.success(request, "User updated."); return redirect("core:superadmin_dashboard")
    return render(request, "core/superadmin_user_form.html", {"form": form, "mode": "edit", "target_user": user})


@superadmin_required
@require_POST
def superadmin_reset_password(request, pk):
    user = get_object_or_404(User, pk=pk)
    if user.is_superadmin: return HttpResponseForbidden("Cannot reset another super admin here.")
    form = PasswordResetForm(request.POST)
    if form.is_valid(): user.set_password(form.cleaned_data["new_password1"]); user.save(update_fields=["password"]); messages.success(request, "Password reset.")
    else: messages.error(request, "Password reset failed: " + _form_errors(form))
    return redirect("core:superadmin_dashboard")


@superadmin_required
@require_POST
def superadmin_toggle_block(request, pk):
    user = get_object_or_404(User, pk=pk)
    if user.is_superadmin: return HttpResponseForbidden("Cannot block super admins.")
    user.is_active = not user.is_active; user.save(update_fields=["is_active"])
    messages.success(request, f"{user.display_name} is now {'active' if user.is_active else 'blocked'}.")
    return redirect("core:superadmin_dashboard")


@superadmin_required
@require_POST
def superadmin_delete_user(request, pk):
    user = get_object_or_404(User, pk=pk)
    if user.is_superadmin: return HttpResponseForbidden("Cannot delete super admins.")
    if user.applications.exists(): messages.error(request, "This user has service history. Block the account instead of deleting it.")
    else: user.delete(); messages.success(request, "User deleted.")
    return redirect("core:superadmin_dashboard")


@superadmin_required
@require_POST
def superadmin_rule(request, pk=None):
    rule = get_object_or_404(SystemRule, pk=pk) if pk else SystemRule()
    form = SystemRuleForm(request.POST, instance=rule)
    if form.is_valid():
        obj = form.save(commit=False); obj.updated_by = request.user
        if not obj.key:
            base = (slugify(obj.label, allow_unicode=True).replace("-", "_") or "rule")[:70]
            key, n = base, 2
            while SystemRule.objects.filter(key=key).exists():
                key = f"{base}_{n}"; n += 1
            obj.key = key
        obj.save(); messages.success(request, "Rule saved.")
    else: messages.error(request, "Could not save rule: " + _form_errors(form))
    return redirect("core:superadmin_dashboard")


@superadmin_required
def superadmin_worker_stats(request):
    now = timezone.now(); workers = User.objects.filter(role=User.WORKER).prefetch_related("specializations")
    data = []
    for worker in workers:
        qs = Application.objects.filter(assigned_worker=worker)
        data.append({"worker": worker, "active": qs.exclude(status=Application.DONE).count(), "completed": qs.filter(status=Application.DONE).count(), "urgent": qs.filter(is_urgent=True).count(), "today": qs.filter(completed_at__date=timezone.localdate()).count(), "week": qs.filter(completed_at__gte=now-timedelta(days=7), status=Application.DONE).count(), "month": qs.filter(completed_at__gte=now-timedelta(days=30), status=Application.DONE).count()})
    return render(request, "core/superadmin_worker_stats.html", {"worker_data": data})
