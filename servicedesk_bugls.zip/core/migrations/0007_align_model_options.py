from django.db import migrations


class Migration(migrations.Migration):
    dependencies = [("core", "0006_align_current_models")]

    operations = [
        migrations.AlterModelOptions(
            name="equipmenttype",
            options={"ordering": ["name"]},
        ),
        migrations.AlterModelOptions(
            name="department",
            options={"ordering": ["name"]},
        ),
    ]
