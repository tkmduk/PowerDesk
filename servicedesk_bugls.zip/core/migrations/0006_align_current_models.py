from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("core", "0005_enterprise_platform")]

    operations = [
        migrations.AlterField(
            model_name="user",
            name="specializations",
            field=models.ManyToManyField(blank=True, related_name="workers", to="core.equipmenttype"),
        ),
        migrations.AlterField(
            model_name="application",
            name="customer_name",
            field=models.CharField(max_length=200),
        ),
        migrations.AlterField(
            model_name="application",
            name="room",
            field=models.CharField(max_length=100),
        ),
        migrations.AlterField(
            model_name="application",
            name="description",
            field=models.TextField(),
        ),
        migrations.AlterField(
            model_name="application",
            name="inner_phone",
            field=models.CharField(max_length=4),
        ),
        migrations.AlterField(
            model_name="application",
            name="equipment_types",
            field=models.ManyToManyField(blank=True, related_name="legacy_applications", to="core.equipmenttype"),
        ),
        migrations.AlterField(
            model_name="application",
            name="status",
            field=models.CharField(
                choices=[
                    ("submitted", "Waiting for dispatcher"),
                    ("assigned", "Assigned"),
                    ("in_progress", "In progress"),
                    ("done", "Completed"),
                ],
                db_index=True,
                default="submitted",
                max_length=20,
            ),
        ),
        migrations.AlterField(
            model_name="application",
            name="is_urgent",
            field=models.BooleanField(db_index=True, default=False),
        ),
        migrations.AlterField(
            model_name="application",
            name="created_at",
            field=models.DateTimeField(auto_now_add=True, db_index=True),
        ),
        migrations.AlterField(
            model_name="applicationevent",
            name="event_type",
            field=models.CharField(
                choices=[
                    ("created", "Created"),
                    ("assigned", "Assigned"),
                    ("started", "Started"),
                    ("completed", "Completed"),
                    ("marked_urgent", "Marked urgent"),
                    ("marked_sensitive", "Marked sensitive"),
                    ("unassigned", "Unassigned"),
                    ("note_added", "Note Added"),
                    ("blocked", "Blocked"),
                ],
                max_length=30,
            ),
        ),
        migrations.AlterField(
            model_name="applicationevent",
            name="created_at",
            field=models.DateTimeField(auto_now_add=True, db_index=True),
        ),
        migrations.AlterModelOptions(
            name="application",
            options={"ordering": ["-is_urgent", "-created_at"]},
        ),
    ]
