import csv
from decimal import Decimal, InvalidOperation

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from core.models import PriceListCategory, PriceListItem


class Command(BaseCommand):
    help = "Import the official repair price list from a CSV file."

    def add_arguments(self, parser):
        parser.add_argument("csv_path", help="CSV file path")
        parser.add_argument("--deactivate-missing", action="store_true", help="Deactivate existing coded items missing from the import")

    @transaction.atomic
    def handle(self, *args, **options):
        path = options["csv_path"]
        try:
            fh = open(path, "r", encoding="utf-8-sig", newline="")
        except OSError as exc:
            raise CommandError(f"Could not open CSV: {exc}") from exc

        required = {"code", "name_en", "name_uz", "name_uz_cyrl", "name_ru", "price", "unit", "sort_order"}
        seen = set()
        categories = {}
        created = updated = 0
        with fh:
            reader = csv.DictReader(fh)
            if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
                missing = required - set(reader.fieldnames or [])
                raise CommandError("Missing CSV columns: " + ", ".join(sorted(missing)))
            if "price_category" not in reader.fieldnames and "equipment_type" not in reader.fieldnames:
                raise CommandError("CSV must contain price_category (or legacy equipment_type).")
            for line_no, row in enumerate(reader, start=2):
                code = (row.get("code") or "").strip()
                name_en = (row.get("name_en") or "").strip()
                if not code or not name_en:
                    raise CommandError(f"Line {line_no}: code and name_en are required.")
                try:
                    price = Decimal((row.get("price") or "0").strip())
                except InvalidOperation as exc:
                    raise CommandError(f"Line {line_no}: invalid price.") from exc
                if price < 0:
                    raise CommandError(f"Line {line_no}: price cannot be negative.")
                category_name = (row.get("price_category") or row.get("equipment_type") or "").strip()
                category = None
                if category_name:
                    category = categories.get(category_name)
                    if category is None:
                        category, _ = PriceListCategory.objects.get_or_create(name=category_name)
                        categories[category_name] = category
                try:
                    sort_order = int((row.get("sort_order") or "0").strip())
                except ValueError as exc:
                    raise CommandError(f"Line {line_no}: sort_order must be an integer.") from exc
                active_raw = str(row.get("active", "1")).strip().lower()
                active = active_raw not in {"0", "false", "no", "off"}
                defaults = {
                    "name_en": name_en,
                    "name_uz": (row.get("name_uz") or "").strip(),
                    "name_uz_cyrl": (row.get("name_uz_cyrl") or "").strip(),
                    "name_ru": (row.get("name_ru") or "").strip(),
                    "price": price,
                    "unit": (row.get("unit") or "").strip(),
                    "equipment_type": None,
                    "price_category": category,
                    "sort_order": sort_order,
                    "active": active,
                }
                obj, was_created = PriceListItem.objects.update_or_create(code=code, defaults=defaults)
                seen.add(code)
                if was_created:
                    created += 1
                else:
                    updated += 1

        if options["deactivate_missing"]:
            qs = PriceListItem.objects.exclude(code__isnull=True).exclude(code__in=seen)
            deactivated = qs.update(active=False)
        else:
            deactivated = 0

        self.stdout.write(self.style.SUCCESS(
            f"Price list imported: {created} created, {updated} updated, {deactivated} deactivated."
        ))
