from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("core", "0003_application_indexes"),
    ]

    operations = [
        migrations.AddField(
            model_name="application",
            name="assigned_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="application",
            name="started_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="application",
            name="completed_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
    ]
