from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):
    dependencies = [("core", "0007_align_model_options")]

    operations = [
        migrations.CreateModel(
            name="PriceListItem",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("code", models.CharField(blank=True, max_length=80, unique=True, null=True)),
                ("name_en", models.CharField(max_length=300)),
                ("name_uz", models.CharField(max_length=300, blank=True, default="")),
                ("name_uz_cyrl", models.CharField(max_length=300, blank=True, default="")),
                ("name_ru", models.CharField(max_length=300, blank=True, default="")),
                ("price", models.DecimalField(decimal_places=2, max_digits=12)),
                ("unit", models.CharField(max_length=50, blank=True, default="")),
                ("sort_order", models.PositiveIntegerField(default=0)),
                ("active", models.BooleanField(default=True)),
                ("equipment_type", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="price_list_items", to="core.equipmenttype")),
            ],
            options={"ordering": ["sort_order", "name_en"]},
        ),
        migrations.AddField(
            model_name="application",
            name="completion_photo",
            field=models.ImageField(blank=True, null=True, upload_to="completion_photos/%Y/%m/%d/"),
        ),
        migrations.AddField(
            model_name="application",
            name="customer_approval_note",
            field=models.TextField(blank=True, default=""),
        ),
        migrations.AddField(
            model_name="application",
            name="customer_approved_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="application",
            name="customer_approved_by",
            field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="approved_applications", to=settings.AUTH_USER_MODEL),
        ),
        migrations.AddField(
            model_name="application",
            name="completion_submitted_at",
            field=models.DateTimeField(blank=True, null=True),
        ),
        migrations.AddField(
            model_name="application",
            name="correction_note",
            field=models.TextField(blank=True, default=""),
        ),
        migrations.CreateModel(
            name="ApplicationWork",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("quantity", models.PositiveIntegerField(default=1)),
                ("price_snapshot", models.DecimalField(decimal_places=2, max_digits=12)),
                ("name_snapshot_en", models.CharField(max_length=300)),
                ("name_snapshot_uz", models.CharField(max_length=300, blank=True, default="")),
                ("name_snapshot_uz_cyrl", models.CharField(max_length=300, blank=True, default="")),
                ("name_snapshot_ru", models.CharField(max_length=300, blank=True, default="")),
                ("created_at", models.DateTimeField(auto_now_add=True)),
                ("application", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="completed_works", to="core.application")),
                ("price_list_item", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="application_works", to="core.pricelistitem")),
            ],
            options={"ordering": ["id"], "constraints": [models.UniqueConstraint(fields=("application", "price_list_item"), name="core_appwork_app_item_uniq")]},
        ),
        migrations.AlterField(
            model_name="application",
            name="status",
            field=models.CharField(
                choices=[
                    ("submitted", "Waiting for dispatcher"),
                    ("assigned", "Assigned"),
                    ("in_progress", "In progress"),
                    ("waiting_approval", "Waiting for customer approval"),
                    ("correction_required", "Correction requested"),
                    ("done", "Completed"),
                ],
                db_index=True,
                default="submitted",
                max_length=25,
            ),
        ),
    ]
