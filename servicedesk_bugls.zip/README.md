# ServiceDesk Enterprise

A production-minded Django service management platform with four isolated role workspaces:

- **Super Admin** — complete visibility, staff/customer management, system rules, audit trail and worker analytics.
- **Dispatcher** — live request queue, specialist matching, workload board, urgency controls and dispatch notes.
- **Worker** — only assigned repairs, category enforcement, start/complete workflow, history and performance chart.
- **Customer** — intentionally minimal portal for submitting service requests and seeing submission status.

## Quick start

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open `http://127.0.0.1:8000/`.

## Accounts

### Super Admin

Create with:

```bash
python manage.py createsuperuser
```

The super admin can create workers and dispatchers from **Command center → Add staff**. Super admins cannot be created from the normal staff form.

### Customer

Customers self-register at `/register/`. Their portal intentionally contains only the service request flow and their own submission history.

### Workers

Create from the super admin console. Every worker must have at least one specialization:

- PC
- Telephone
- Camera

A worker can only start requests whose category matches their specialization.

### Dispatchers

Create from the super admin console. Dispatchers can see the whole active queue, match a request only to a compatible specialist, see current workload, flag urgency/sensitivity and add internal notes.

## Workflow

`Customer submits → Dispatcher sees every request and can assign a matching worker, OR a matching worker takes it themselves (starts immediately) → Worker selects completed price-list works + uploads photo → Customer reviews work names/photo → Customer approves or requests correction → Boss/Super Admin sees the full report with prices`

State transitions are enforced server-side and protected with transactional locking for concurrent assignment/start/complete actions.

## Scaling to 10,000+ requests

The UI uses pagination instead of loading entire histories. Dashboard queries use `select_related`, aggregation and targeted indexes. The project supports `DATABASE_URL`; for a serious deployment use PostgreSQL rather than SQLite.

Example:

```text
DATABASE_URL=postgresql://user:password@host:5432/servicedesk
DJANGO_DEBUG=0
DJANGO_SECRET_KEY=<long-random-secret>
DJANGO_ALLOWED_HOSTS=servicedesk.example.com
DJANGO_TIME_ZONE=UTC
```

For production, put Django behind a reverse proxy, run multiple Gunicorn/Uvicorn workers, use PostgreSQL, serve static files through a CDN/reverse proxy, and add Redis/Celery only when asynchronous jobs/notifications become necessary.

## Design

The interface uses a dark premium glassmorphism system: translucent layered panels, soft ambient light, controlled blur, subtle borders, responsive layouts and role-specific information density. The visual system is shared across portals so the product feels like one coherent enterprise application rather than four unrelated pages.

## Languages

The public website supports four selectable interface languages:

- English (fallback/reference language)
- O‘zbek (Latin)
- Ўзбек (Кирилл)
- Русский

The language selector is available in the public portal header and persists through Django's locale/session language mechanism. User-entered names, departments, equipment names and request descriptions are not automatically translated.

The Django admin has an **independent language preference**. It defaults to **English** regardless of the public site's language. Staff can switch the admin interface to any language configured in `LANGUAGES`; the admin choice is stored separately from the public language choice.


## Official price list and completion reports

Technicians must select every work actually performed from `PriceListItem` before they can submit a repair for customer approval. Customers see the selected work names and proof photo, but never see prices. The super admin/boss can open the full job report and see customer data, technician data, selected price-list items, price snapshots, total price, notes, timestamps, audit events and the proof photo.

The official price list source supplied for this project is the uploaded TSKO calculator archive. It contains **496 active billable rows** across four sections, including the three 1–92 service variants in Calc_1 and items 93–312 in the other calculators. The list has now been imported into the project as `pricelist.official.csv` and is also seeded automatically by migration `0009_seed_official_pricelist`.

A fresh deployment therefore only needs:

```bash
python manage.py migrate
```

The exact UTF-8 CSV is included for audit/import purposes and can also be re-imported with:

```bash
python manage.py import_pricelist pricelist.official.csv --deactivate-missing
```

The supplied source contains Uzbek Latin service names; no Russian translations were present in the source, so those fields are intentionally left blank rather than inventing translations. Uzbek Cyrillic and Russian UI labels remain available, with catalogue names falling back to the official Uzbek source text until translated catalogue fields are supplied.

CSV columns:

```text
code,name_en,name_uz,name_uz_cyrl,name_ru,price,unit,price_category,sort_order,active
```

The same fields are available in Django Admin under **Price list items**, so the boss/admin can review and edit the catalogue.\n\nThe 23 price-list sections are stored in a separate `PriceListCategory` table so they do **not** appear as customer-facing repair equipment categories. Historical application reports keep a snapshot of the selected work name and price, so future price-list changes do not alter old reports.

Completion proof photos are stored under `MEDIA_ROOT/completion_photos/`. In production, serve `MEDIA_ROOT` through the reverse proxy or object storage rather than Django's development media serving.
