from django.db import migrations


def create_defaults(apps, schema_editor):
    Department = apps.get_model("core", "Department")
    EquipmentType = apps.get_model("core", "EquipmentType")

    departments = ["Shtab", "Hoop", "Guur", "Boshqarma", "Markaz"]
    for name in departments:
        Department.objects.get_or_create(name=name)

    equipment = [
        ("PC", "🖥"),
        ("Telephone", "📞"),
        ("Camera", "📷"),
    ]
    for name, icon in equipment:
        EquipmentType.objects.get_or_create(name=name, defaults={"icon": icon})


def remove_defaults(apps, schema_editor):
    Department = apps.get_model("core", "Department")
    EquipmentType = apps.get_model("core", "EquipmentType")
    Department.objects.all().delete()
    EquipmentType.objects.all().delete()


class Migration(migrations.Migration):

    dependencies = [
        ("core", "0001_initial"),
    ]

    operations = [
        migrations.RunPython(create_defaults, remove_defaults),
    ]
