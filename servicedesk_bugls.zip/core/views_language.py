from django.conf import settings
from django.http import HttpResponseBadRequest
from django.shortcuts import redirect
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST


@require_POST
def admin_language(request):
    language = request.POST.get('language', settings.ADMIN_DEFAULT_LANGUAGE)
    allowed = {code for code, _ in settings.LANGUAGES}
    if language not in allowed:
        return HttpResponseBadRequest('Unsupported language.')
    request.session['admin_language'] = language
    request.session.modified = True
    next_url = request.POST.get('next') or '/admin/'
    if not url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}, require_https=request.is_secure()):
        next_url = '/admin/'
    return redirect(next_url)
