from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("core", "0002_seed_data"),
    ]

    operations = [
        migrations.AddIndex(
            model_name="application",
            index=models.Index(fields=["status", "-created_at"], name="core_app_status_created_idx"),
        ),
        migrations.AddIndex(
            model_name="application",
            index=models.Index(fields=["assigned_worker", "status"], name="core_app_worker_status_idx"),
        ),
        migrations.AddIndex(
            model_name="application",
            index=models.Index(fields=["customer", "-created_at"], name="core_app_customer_created_idx"),
        ),
        migrations.AddIndex(
            model_name="application",
            index=models.Index(fields=["is_urgent", "status"], name="core_app_urgent_status_idx"),
        ),
    ]
