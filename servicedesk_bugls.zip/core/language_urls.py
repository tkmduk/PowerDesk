from django.urls import path
from .views_language import admin_language

app_name = "language"
urlpatterns = [path("set/", admin_language, name="admin_language")]
