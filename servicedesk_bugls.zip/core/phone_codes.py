"""Uzbekistan-only phone formatting and normalization.

Rules (mirrored in static/core/app.js):
* A number is nine local digits, e.g. 90 123 45 67  ->  +998901234567.
* A leading ``998`` is a country code ONLY when 12+ digits are present.
  ``99 812 34 56`` is a valid local number that merely starts with 998.
* A leading ``8`` is a trunk prefix ONLY when exactly 10 digits are present.
  ``88 123 45 67`` is a valid local number that starts with 8.
"""

UZBEKISTAN_CODE = "+998"
UZBEKISTAN_FLAG = "\U0001F1FA\U0001F1FF"

# Kept as a one-item tuple for compatibility with code that imports choices.
COUNTRY_CHOICES = ((UZBEKISTAN_CODE, f"{UZBEKISTAN_FLAG} {UZBEKISTAN_CODE}"),)


def local_digits(raw):
    """Return the local digits of a phone number (nine when complete)."""
    raw = str(raw or "")
    digits = "".join(c for c in raw if c.isdigit())
    if len(digits) >= 12 and digits.startswith("998"):
        digits = digits[3:]
    elif len(digits) == 10 and digits.startswith("8"):
        digits = digits[1:]
    return digits


def normalize_phone(*parts):
    """Return a canonical Uzbek phone number: +998XXXXXXXXX.

    Accepts either ``normalize_phone(local)`` or the old
    ``normalize_phone('+998', local)`` signature for compatibility.
    """
    return f"{UZBEKISTAN_CODE}{local_digits(''.join(str(p or '') for p in parts))}"


def split_phone(phone_number):
    """Return (country code, nine-digit local number) for a stored number."""
    return UZBEKISTAN_CODE, local_digits(phone_number)[:9]
