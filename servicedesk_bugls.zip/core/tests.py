from django.test import TestCase
from django.urls import reverse
from .models import User, EquipmentType, Department, Application, ApplicationEvent, Notification, PriceListItem, ApplicationWork
from .forms import CustomerRegistrationForm, PhoneLoginForm, PhoneField, format_uz_phone
from .phone_codes import normalize_phone


class PhoneUXTests(TestCase):
    def test_uzbek_phone_normalization(self):
        form = CustomerRegistrationForm(data={
            "full_name": "Test Customer",
            "phone_number": "(99) 123 - 11 - 22",
            "password1": "StrongPassword123!",
            "password2": "StrongPassword123!",
        })
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.cleaned_data["phone_number"], "+998991231122")

    def test_login_accepts_formatted_uzbek_phone(self):
        user = User.objects.create_user(phone_number="+998991231122", password="StrongPassword123!", full_name="Test")
        form = PhoneLoginForm(data={"username": "(99) 123 - 11 - 22", "password": "StrongPassword123!"})
        self.assertTrue(form.is_valid(), form.errors)
        self.assertEqual(form.get_user().pk, user.pk)

    def test_logout_requires_post_and_logs_user_out(self):
        user = User.objects.create_user(phone_number="+998901234567", password="StrongPassword123!", full_name="Test")
        self.client.force_login(user)
        self.assertEqual(self.client.get(reverse("core:logout")).status_code, 405)
        response = self.client.post(reverse("core:logout"))
        self.assertRedirects(response, reverse("core:login"))
        self.assertNotIn("_auth_user_id", self.client.session)



class PhoneRulesTests(TestCase):
    def test_local_number_starting_with_998_is_not_treated_as_country_code(self):
        self.assertEqual(PhoneField().clean("(99) 812 - 34 - 56"), "+998998123456")
        self.assertEqual(PhoneField().clean("998123456"), "+998998123456")

    def test_country_code_and_trunk_prefix_are_stripped_only_when_full_length(self):
        for raw in ("+998 90 123 45 67", "998901234567", "8 90 123 45 67", "(90) 123 - 45 - 67"):
            self.assertEqual(PhoneField().clean(raw), "+998901234567", raw)
        self.assertEqual(PhoneField().clean("88 123 45 67"), "+998881234567")  # valid local 88-prefix

    def test_invalid_lengths_rejected(self):
        for raw in ("90 123 45 6", "90 123 45 678 9", "abc"):
            with self.assertRaises(Exception):
                PhoneField().clean(raw)

    def test_server_format_matches_browser_mask(self):
        self.assertEqual(format_uz_phone("901234567"), "(90) 123 - 45 - 67")
        self.assertEqual(format_uz_phone("90123"), "(90) 123")
        self.assertEqual(format_uz_phone("9"), "(9")
        self.assertEqual(format_uz_phone(""), "")

    def test_manager_normalizes_so_createsuperuser_can_log_in(self):
        user = User.objects.create_superuser(phone_number="90 123 45 67", password="StrongPassword123!", full_name="Root")
        self.assertEqual(user.phone_number, "+998901234567")
        self.assertEqual(User.objects.get_by_natural_key("901234567").pk, user.pk)
        form = PhoneLoginForm(data={"username": "(90) 123 - 45 - 67", "password": "StrongPassword123!"})
        self.assertTrue(form.is_valid(), form.errors)

    def test_widgets_do_not_limit_formatted_length(self):
        self.assertNotIn("maxlength", str(CustomerRegistrationForm()["phone_number"]))
        self.assertNotIn("maxlength", str(PhoneLoginForm()["username"]))


class ServiceDeskTestCase(TestCase):
    @classmethod
    def setUpTestData(cls):
        cls.pc = EquipmentType.objects.get_or_create(name="PC", defaults={"icon": "🖥"})[0]
        cls.phone = EquipmentType.objects.get_or_create(name="Telephone", defaults={"icon": "📞"})[0]
        cls.camera = EquipmentType.objects.get_or_create(name="Camera", defaults={"icon": "📷"})[0]
        cls.department = Department.objects.get_or_create(name="Shtab")[0]
        cls.customer = User.objects.create_user("+998901111111", "CustomerPass123!", full_name="Customer")
        cls.worker = User.objects.create_user("+998902222222", "WorkerPass123!", full_name="PC Technician", role=User.WORKER)
        cls.worker.specializations.add(cls.pc)
        cls.phone_worker = User.objects.create_user("+998903333333", "WorkerPass123!", full_name="Phone Technician", role=User.WORKER)
        cls.phone_worker.specializations.add(cls.phone)
        cls.dispatcher = User.objects.create_user("+998904444444", "DispatcherPass123!", full_name="Dispatcher", role=User.DISPATCHER)
        cls.admin = User.objects.create_superuser("+998905555555", "AdminPass123!", full_name="Super Admin")

    def make_application(self, equipment=None, status=Application.SUBMITTED, worker=None):
        app = Application.objects.create(
            customer=self.customer, customer_name="Customer", department=self.department,
            room="204", equipment_type=equipment or self.pc, description="No power", inner_phone="1234",
            status=status, assigned_worker=worker,
        )
        app.equipment_types.add(equipment or self.pc)
        return app


class AccessTests(ServiceDeskTestCase):
    def test_role_redirects(self):
        for user, url in [(self.customer, "core:customer_dashboard"), (self.worker, "core:worker_dashboard"), (self.dispatcher, "core:dispatcher_dashboard"), (self.admin, "core:superadmin_dashboard")]:
            self.client.force_login(user)
            self.assertRedirects(self.client.get(reverse("core:dashboard")), reverse(url))

    def test_customer_cannot_open_dispatch(self):
        self.client.force_login(self.customer)
        self.assertEqual(self.client.get(reverse("core:dispatcher_dashboard")).status_code, 403)


class CustomerFlowTests(ServiceDeskTestCase):
    def test_customer_creates_request_and_dispatcher_is_notified(self):
        self.client.force_login(self.customer)
        response = self.client.post(reverse("core:customer_dashboard"), {
            "customer_name": "Customer", "department": self.department.pk, "room": "101",
            "equipment_type": self.pc.pk, "description": "Broken computer", "inner_phone": "1234",
        })
        self.assertRedirects(response, reverse("core:customer_dashboard"))
        app = Application.objects.latest("id")
        self.assertEqual(app.status, Application.SUBMITTED)
        self.assertEqual(app.equipment_type, self.pc)
        self.assertTrue(Notification.objects.filter(user=self.dispatcher, application=app).exists())
        self.assertTrue(app.events.filter(event_type=ApplicationEvent.CREATED).exists())


class DispatchFlowTests(ServiceDeskTestCase):
    def test_dispatcher_can_assign_matching_specialist(self):
        app = self.make_application()
        self.client.force_login(self.dispatcher)
        response = self.client.post(reverse("core:assign_worker", args=[app.pk]), {"worker": self.worker.pk})
        self.assertRedirects(response, reverse("core:dispatcher_dashboard"))
        app.refresh_from_db()
        self.assertEqual(app.assigned_worker, self.worker)
        self.assertEqual(app.status, Application.ASSIGNED)
        self.assertTrue(Notification.objects.filter(user=self.worker, application=app).exists())

    def test_dispatcher_cannot_assign_wrong_specialist(self):
        app = self.make_application(equipment=self.phone)
        self.client.force_login(self.dispatcher)
        response = self.client.post(reverse("core:assign_worker", args=[app.pk]), {"worker": self.worker.pk})
        self.assertEqual(response.status_code, 403)
        app.refresh_from_db()
        self.assertIsNone(app.assigned_worker)

    def test_in_progress_job_cannot_be_reassigned(self):
        app = self.make_application(status=Application.IN_PROGRESS, worker=self.worker)
        self.client.force_login(self.dispatcher)
        response = self.client.post(reverse("core:assign_worker", args=[app.pk]), {"worker": self.worker.pk})
        self.assertEqual(response.status_code, 400)


class WorkerFlowTests(ServiceDeskTestCase):
    def test_worker_only_sees_assigned_work(self):
        assigned = self.make_application(status=Application.ASSIGNED, worker=self.worker)
        unassigned = self.make_application()
        self.client.force_login(self.worker)
        response = self.client.get(reverse("core:worker_dashboard"))
        self.assertContains(response, f"#{assigned.pk}")
        self.assertNotContains(response, f"#{unassigned.pk}")

    def test_worker_can_start_own_job(self):
        app = self.make_application(status=Application.ASSIGNED, worker=self.worker)
        self.client.force_login(self.worker)
        response = self.client.post(reverse("core:worker_start", args=[app.pk]))
        self.assertRedirects(response, reverse("core:worker_dashboard"))
        app.refresh_from_db()
        self.assertEqual(app.status, Application.IN_PROGRESS)
        self.assertIsNotNone(app.started_at)

    def test_worker_cannot_start_wrong_category(self):
        app = self.make_application(equipment=self.phone, status=Application.ASSIGNED, worker=self.worker)
        self.client.force_login(self.worker)
        self.assertEqual(self.client.post(reverse("core:worker_start", args=[app.pk])).status_code, 403)

    def test_worker_completion_page_is_reachable(self):
        item = PriceListItem.objects.create(code="PC-001", name_en="Power supply replacement", price="25000.00")
        app = self.make_application(status=Application.IN_PROGRESS, worker=self.worker)
        self.client.force_login(self.worker)
        response = self.client.get(reverse("core:worker_complete", args=[app.pk]))
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "Power supply replacement")


class CustomerApprovalTests(ServiceDeskTestCase):
    def test_customer_can_approve_waiting_job(self):
        item = PriceListItem.objects.create(code="PC-001", name_en="Power supply replacement", price="25000.00")
        app = self.make_application(status=Application.WAITING_APPROVAL, worker=self.worker)
        ApplicationWork.objects.create(application=app, price_list_item=item, price_snapshot=item.price, name_snapshot_en=item.name_en)
        self.client.force_login(self.customer)
        response = self.client.post(reverse("core:customer_approve", args=[app.pk]), {"note": "Looks good."})
        self.assertRedirects(response, reverse("core:customer_dashboard"))
        app.refresh_from_db()
        self.assertEqual(app.status, Application.DONE)
        self.assertIsNotNone(app.customer_approved_at)


class SuperAdminTests(ServiceDeskTestCase):
    def test_admin_can_create_worker_with_specialization(self):
        self.client.force_login(self.admin)
        response = self.client.post(reverse("core:superadmin_user_create"), {
            "phone_number": "(90) 666 - 66 - 66", "full_name": "New PC Tech",
            "role": User.WORKER, "password1": "StrongStaffPass123!", "password2": "StrongStaffPass123!", "specializations": [self.pc.pk],
        })
        self.assertRedirects(response, reverse("core:superadmin_dashboard"))
        user = User.objects.get(phone_number="+998906666666")
        self.assertTrue(user.is_worker)
        self.assertIn(self.pc, user.specializations.all())

    def test_dispatcher_creation_ignores_specializations(self):
        self.client.force_login(self.admin)
        response = self.client.post(reverse("core:superadmin_user_create"), {
            "phone_number": "(90) 777 - 77 - 77", "full_name": "New Dispatcher",
            "role": User.DISPATCHER, "password1": "StrongStaffPass123!", "password2": "StrongStaffPass123!", "specializations": [self.pc.pk],
        })
        self.assertRedirects(response, reverse("core:superadmin_dashboard"))
        user = User.objects.get(phone_number="+998907777777")
        self.assertTrue(user.is_dispatcher)
        self.assertEqual(user.specializations.count(), 0)

    def test_worker_without_specialization_is_rejected_and_phone_kept(self):
        self.client.force_login(self.admin)
        response = self.client.post(reverse("core:superadmin_user_create"), {
            "phone_number": "(90) 888 - 88 - 88", "full_name": "No Spec",
            "role": User.WORKER, "password1": "StrongStaffPass123!", "password2": "StrongStaffPass123!",
        })
        self.assertEqual(response.status_code, 200)
        self.assertContains(response, "(90) 888 - 88 - 88")
        self.assertFalse(User.objects.filter(phone_number="+998908888888").exists())

    def test_admin_can_block_customer_but_not_delete_history(self):
        app = self.make_application()
        self.client.force_login(self.admin)
        response = self.client.post(reverse("core:superadmin_delete_user", args=[self.customer.pk]))
        self.assertRedirects(response, reverse("core:superadmin_dashboard"))
        self.customer.refresh_from_db()
        self.assertTrue(self.customer.is_active)
        self.client.post(reverse("core:superadmin_toggle_block", args=[self.customer.pk]))
        self.customer.refresh_from_db()
        self.assertFalse(self.customer.is_active)


class RegressionTests(ServiceDeskTestCase):
    def test_worker_and_superadmin_dashboards_render(self):
        # These templates used to put {% load %} before {% extends %}, which raises TemplateSyntaxError.
        self.client.force_login(self.worker)
        self.assertEqual(self.client.get(reverse("core:worker_dashboard")).status_code, 200)
        self.client.force_login(self.admin)
        self.assertEqual(self.client.get(reverse("core:superadmin_dashboard")).status_code, 200)

    def test_job_waiting_for_approval_cannot_be_reassigned(self):
        app = self.make_application(status=Application.WAITING_APPROVAL, worker=self.worker)
        self.client.force_login(self.dispatcher)
        response = self.client.post(reverse("core:assign_worker", args=[app.pk]), {"worker": self.worker.pk})
        self.assertEqual(response.status_code, 400)
        app.refresh_from_db()
        self.assertEqual(app.status, Application.WAITING_APPROVAL)

    def test_blocked_user_sees_blocked_message(self):
        self.customer.is_active = False
        self.customer.save(update_fields=["is_active"])
        response = self.client.post(reverse("core:login"), {"username": "(90) 111 - 11 - 11", "password": "CustomerPass123!"})
        self.assertContains(response, "This account is blocked")

    def test_admin_language_switch_rejects_external_redirect(self):
        response = self.client.post(reverse("language:admin_language"), {"language": "en", "next": "https://evil.example/"})
        self.assertEqual(response.status_code, 302)
        self.assertEqual(response["Location"], "/admin/")

    def test_duplicate_rule_labels_get_unique_keys(self):
        from .models import SystemRule
        self.client.force_login(self.admin)
        for _ in range(2):
            self.client.post(reverse("core:superadmin_rule_create"), {"label": "Max jobs", "value": "5", "description": ""})
        self.assertEqual(SystemRule.objects.filter(label="Max jobs").count(), 2)


class SelfClaimTests(ServiceDeskTestCase):
    def test_new_request_is_visible_to_matching_worker_only(self):
        app = self.make_application()
        self.client.force_login(self.worker)
        self.assertContains(self.client.get(reverse("core:worker_dashboard")), "Take this job")
        self.client.force_login(self.phone_worker)
        self.assertNotContains(self.client.get(reverse("core:worker_dashboard")), f"#{app.pk}")

    def test_worker_takes_job_and_it_starts(self):
        app = self.make_application()
        self.client.force_login(self.worker)
        self.client.post(reverse("core:worker_claim", args=[app.pk]))
        app.refresh_from_db()
        self.assertEqual(app.assigned_worker, self.worker)
        self.assertEqual(app.status, Application.IN_PROGRESS)

    def test_second_worker_cannot_take_taken_job(self):
        other = User.objects.create_user("+998906666666", "WorkerPass123!", full_name="Other PC", role=User.WORKER)
        other.specializations.add(self.pc)
        app = self.make_application(status=Application.IN_PROGRESS, worker=self.worker)
        self.client.force_login(other)
        self.client.post(reverse("core:worker_claim", args=[app.pk]))
        app.refresh_from_db()
        self.assertEqual(app.assigned_worker, self.worker)

    def test_worker_cannot_take_wrong_category(self):
        app = self.make_application(equipment=self.phone)
        self.client.force_login(self.worker)
        self.assertEqual(self.client.post(reverse("core:worker_claim", args=[app.pk])).status_code, 403)


class CategoryVisibilityTests(ServiceDeskTestCase):
    def test_multi_category_worker_sees_both_but_not_others(self):
        pc_app = self.make_application(equipment=self.pc)
        cam_app = self.make_application(equipment=self.camera)
        tel_app = self.make_application(equipment=self.phone)
        self.worker.specializations.add(self.camera)
        self.client.force_login(self.worker)
        html = self.client.get(reverse("core:worker_dashboard")).content.decode()
        self.assertIn(f"/worker/apps/{pc_app.pk}/claim/", html)
        self.assertIn(f"/worker/apps/{cam_app.pk}/claim/", html)
        self.assertNotIn(f"/worker/apps/{tel_app.pk}/claim/", html)

    def test_taken_job_visible_read_only_to_same_category_colleague(self):
        other = User.objects.create_user("+998907777777", "WorkerPass123!", full_name="Other PC", role=User.WORKER)
        other.specializations.add(self.pc)
        app = self.make_application(status=Application.IN_PROGRESS, worker=other)
        self.client.force_login(self.worker)
        html = self.client.get(reverse("core:worker_dashboard")).content.decode()
        self.assertIn(f"#{app.pk}", html)
        self.assertNotIn(f"/worker/apps/{app.pk}/claim/", html)


class DualPathTests(ServiceDeskTestCase):
    def test_new_request_notifies_dispatcher_and_matching_worker(self):
        self.client.force_login(self.customer)
        self.client.post(reverse("core:customer_dashboard"), {
            "customer_name": "Customer", "department": self.department.pk, "room": "101",
            "equipment_type": self.pc.pk, "description": "Broken computer", "inner_phone": "1234",
        })
        app = Application.objects.latest("id")
        self.assertTrue(Notification.objects.filter(user=self.dispatcher, application=app).exists())
        self.assertTrue(Notification.objects.filter(user=self.worker, application=app).exists())
        self.assertFalse(Notification.objects.filter(user=self.phone_worker, application=app).exists())

    def test_dispatcher_sees_all_and_assigned_job_is_not_claimable(self):
        app = self.make_application()
        self.client.force_login(self.dispatcher)
        self.assertContains(self.client.get(reverse("core:dispatcher_dashboard")), f"#{app.pk}")
        self.client.post(reverse("core:assign_worker", args=[app.pk]), {"worker": self.worker.pk})
        other = User.objects.create_user("+998908000000", "WorkerPass123!", full_name="Other PC", role=User.WORKER)
        other.specializations.add(self.pc)
        self.client.force_login(other)
        self.client.post(reverse("core:worker_claim", args=[app.pk]))
        app.refresh_from_db()
        self.assertEqual(app.assigned_worker, self.worker)
