from django import forms
from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from django.contrib.auth.forms import ReadOnlyPasswordHashField
from django.contrib.auth.password_validation import validate_password
from .phone_codes import normalize_phone
from .models import User, Application, ApplicationEvent, EquipmentType, Department, SystemRule, Notification, PriceListCategory, PriceListItem, ApplicationWork


class AdminUserCreationForm(forms.ModelForm):
    password1 = forms.CharField(widget=forms.PasswordInput)
    password2 = forms.CharField(widget=forms.PasswordInput)
    class Meta:
        model = User
        fields = ("phone_number", "full_name", "role", "is_active", "is_staff")
    def clean_phone_number(self):
        return normalize_phone(self.cleaned_data["phone_number"])
    def clean(self):
        data = super().clean()
        if data.get("password1") != data.get("password2"): raise forms.ValidationError("Passwords do not match.")
        if data.get("password1"):
            try: validate_password(data["password1"], self.instance)
            except forms.ValidationError as exc: self.add_error("password1", exc)
        return data
    def save(self, commit=True):
        user = super().save(commit=False); user.set_password(self.cleaned_data["password1"])
        if commit: user.save()
        return user


class AdminUserChangeForm(forms.ModelForm):
    password = ReadOnlyPasswordHashField(label="Password")
    class Meta:
        model = User
        fields = ("phone_number", "password", "full_name", "role", "specializations", "is_active", "is_staff", "is_superuser", "groups", "user_permissions")
    def clean_phone_number(self):
        return normalize_phone(self.cleaned_data["phone_number"])


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    form = AdminUserChangeForm; add_form = AdminUserCreationForm
    list_display = ("phone_number", "full_name", "role", "is_active", "is_staff")
    list_filter = ("role", "is_active", "is_staff")
    search_fields = ("phone_number", "full_name")
    ordering = ("-date_joined",)
    fieldsets = ((None, {"fields": ("phone_number", "password")}), ("Profile", {"fields": ("full_name", "role", "specializations")}), ("Permissions", {"fields": ("is_active", "is_staff", "is_superuser", "groups", "user_permissions")}), ("Dates", {"fields": ("last_login", "date_joined")}))
    add_fieldsets = ((None, {"fields": ("phone_number", "full_name", "role", "is_active", "is_staff", "password1", "password2")}),)


@admin.register(EquipmentType)
class EquipmentTypeAdmin(admin.ModelAdmin):
    list_display = ("name", "icon", "active")
    list_filter = ("active",)
    search_fields = ("name",)


@admin.register(Department)
class DepartmentAdmin(admin.ModelAdmin):
    list_display = ("name", "active")
    list_filter = ("active",)
    search_fields = ("name",)


class ApplicationWorkInline(admin.TabularInline):
    model = ApplicationWork
    extra = 0
    can_delete = False
    readonly_fields = ("price_list_item", "quantity", "price_snapshot", "name_snapshot_en", "name_snapshot_uz", "name_snapshot_uz_cyrl", "name_snapshot_ru", "created_at")

@admin.register(Application)
class ApplicationAdmin(admin.ModelAdmin):
    list_display = ("id", "equipment_type", "customer_name", "status", "assigned_worker", "is_urgent", "created_at")
    list_filter = ("status", "equipment_type", "is_urgent", "is_sensitive", "department")
    search_fields = ("=id", "customer_name", "room", "inner_phone", "description")
    list_select_related = ("customer", "department", "equipment_type", "assigned_worker", "assigned_by")
    autocomplete_fields = ("customer", "assigned_worker", "assigned_by", "customer_approved_by")
    readonly_fields = ("created_at", "updated_at", "assigned_at", "started_at", "completed_at", "completion_submitted_at", "customer_approved_at")
    inlines = (ApplicationWorkInline,)


@admin.register(ApplicationEvent)
class ApplicationEventAdmin(admin.ModelAdmin):
    list_display = ("application", "actor", "event_type", "created_at")
    list_filter = ("event_type",)
    search_fields = ("notes", "application__customer_name", "actor__full_name")
    readonly_fields = ("created_at",)
    list_select_related = ("application", "actor")


@admin.register(SystemRule)
class SystemRuleAdmin(admin.ModelAdmin):
    list_display = ("label", "key", "value", "updated_at", "updated_by")
    search_fields = ("label", "key", "value")




@admin.register(PriceListCategory)
class PriceListCategoryAdmin(admin.ModelAdmin):
    list_display = ("name", "icon", "active", "sort_order")
    list_filter = ("active",)
    search_fields = ("name",)
    list_editable = ("icon", "active", "sort_order")
    ordering = ("sort_order", "name")

@admin.register(PriceListItem)
class PriceListItemAdmin(admin.ModelAdmin):
    list_display = ("code", "name_en", "price", "unit", "price_category", "active", "sort_order")
    list_filter = ("active", "price_category")
    search_fields = ("code", "name_en", "name_uz", "name_uz_cyrl", "name_ru")
    list_editable = ("price", "active", "sort_order")
    ordering = ("sort_order", "name_en")
    autocomplete_fields = ("price_category", "equipment_type")


@admin.register(ApplicationWork)
class ApplicationWorkAdmin(admin.ModelAdmin):
    list_display = ("application", "price_list_item", "quantity", "price_snapshot", "created_at")
    list_filter = ("price_list_item__price_category",)
    search_fields = ("application__customer_name", "name_snapshot_en", "name_snapshot_uz", "name_snapshot_uz_cyrl", "name_snapshot_ru")
    readonly_fields = ("application", "price_list_item", "quantity", "price_snapshot", "name_snapshot_en", "name_snapshot_uz", "name_snapshot_uz_cyrl", "name_snapshot_ru", "created_at")
    list_select_related = ("application", "price_list_item")


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ("user", "title", "read_at", "created_at")
    list_filter = ("read_at",)
    search_fields = ("user__full_name", "title", "body")
    list_select_related = ("user", "application")
