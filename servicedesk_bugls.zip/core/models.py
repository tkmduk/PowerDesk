from django.conf import settings
from django.contrib.auth.models import AbstractUser, BaseUserManager
from django.db import models

from .phone_codes import normalize_phone


class UserManager(BaseUserManager):
    def create_user(self, phone_number, password=None, **extra_fields):
        if not phone_number:
            raise ValueError("Phone number is required")
        phone_number = normalize_phone(phone_number)
        user = self.model(phone_number=phone_number, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def get_by_natural_key(self, phone_number):
        return super().get_by_natural_key(normalize_phone(phone_number))

    def create_superuser(self, phone_number, password=None, **extra_fields):
        extra_fields.update(role=User.SUPERADMIN, is_staff=True, is_superuser=True)
        extra_fields.setdefault("is_active", True)
        return self.create_user(phone_number, password, **extra_fields)


class EquipmentType(models.Model):
    name = models.CharField(max_length=50, unique=True)
    icon = models.CharField(max_length=10, default="🖥")
    color = models.CharField(max_length=20, default="violet")
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class Department(models.Model):
    name = models.CharField(max_length=100, unique=True)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ["name"]

    def __str__(self):
        return self.name


class User(AbstractUser):
    CUSTOMER = "customer"
    WORKER = "worker"
    DISPATCHER = "dispatcher"
    SUPERADMIN = "superadmin"
    ROLE_CHOICES = [
        (CUSTOMER, "Customer"),
        (WORKER, "Worker"),
        (DISPATCHER, "Dispatcher"),
        (SUPERADMIN, "Super Admin"),
    ]

    username = None
    phone_number = models.CharField(max_length=20, unique=True, verbose_name="Phone number")
    full_name = models.CharField(max_length=200, default="")
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default=CUSTOMER, db_index=True)
    specializations = models.ManyToManyField(EquipmentType, blank=True, related_name="workers")

    USERNAME_FIELD = "phone_number"
    REQUIRED_FIELDS = ["full_name"]
    objects = UserManager()

    @property
    def display_name(self):
        return self.full_name or self.phone_number

    @property
    def is_customer(self): return self.role == self.CUSTOMER
    @property
    def is_worker(self): return self.role == self.WORKER
    @property
    def is_dispatcher(self): return self.role == self.DISPATCHER
    @property
    def is_superadmin(self): return self.role == self.SUPERADMIN

    def __str__(self):
        return f"{self.display_name} ({self.phone_number})"


class SystemRule(models.Model):
    """Small editable operational rules controlled by super admins."""
    key = models.CharField(max_length=80, unique=True)
    label = models.CharField(max_length=160)
    value = models.CharField(max_length=200)
    description = models.TextField(blank=True)
    updated_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ["label"]

    def __str__(self):
        return f"{self.label}: {self.value}"


class Application(models.Model):
    SUBMITTED = "submitted"
    ASSIGNED = "assigned"
    IN_PROGRESS = "in_progress"
    DONE = "done"
    WAITING_APPROVAL = "waiting_approval"
    CORRECTION_REQUIRED = "correction_required"
    STATUS_CHOICES = [
        (SUBMITTED, "Waiting for dispatcher"),
        (ASSIGNED, "Assigned"),
        (IN_PROGRESS, "In progress"),
        (WAITING_APPROVAL, "Waiting for customer approval"),
        (CORRECTION_REQUIRED, "Correction requested"),
        (DONE, "Completed"),
    ]

    customer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="applications")
    customer_name = models.CharField(max_length=200)
    department = models.ForeignKey(Department, on_delete=models.PROTECT)
    room = models.CharField(max_length=100)
    equipment_type = models.ForeignKey(EquipmentType, null=True, blank=True, on_delete=models.PROTECT, related_name="applications")
    # Kept for compatibility with the earlier schema. New requests use exactly one equipment_type.
    equipment_types = models.ManyToManyField(EquipmentType, blank=True, related_name="legacy_applications")
    description = models.TextField()
    inner_phone = models.CharField(max_length=4)
    status = models.CharField(max_length=25, choices=STATUS_CHOICES, default=SUBMITTED, db_index=True)
    assigned_worker = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="assigned_applications")
    assigned_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="dispatched_applications")
    is_urgent = models.BooleanField(default=False, db_index=True)
    is_sensitive = models.BooleanField(default=False)
    dispatcher_notes = models.TextField(blank=True, default="")
    resolution_notes = models.TextField(blank=True, default="")
    correction_note = models.TextField(blank=True, default="")
    completion_photo = models.ImageField(upload_to="completion_photos/%Y/%m/%d/", null=True, blank=True)
    completion_submitted_at = models.DateTimeField(null=True, blank=True)
    customer_approval_note = models.TextField(blank=True, default="")
    customer_approved_at = models.DateTimeField(null=True, blank=True)
    customer_approved_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="approved_applications")
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)
    updated_at = models.DateTimeField(auto_now=True)
    assigned_at = models.DateTimeField(null=True, blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ["-is_urgent", "-created_at"]
        indexes = [
            models.Index(fields=["status", "-created_at"], name="core_app_status_created_idx"),
            models.Index(fields=["assigned_worker", "status"], name="core_app_worker_status_idx"),
            models.Index(fields=["customer", "-created_at"], name="core_app_customer_created_idx"),
            models.Index(fields=["equipment_type", "status", "-created_at"], name="core_app_type_status_idx"),
            models.Index(fields=["is_urgent", "status", "-created_at"], name="core_app_urgent_status_idx"),
        ]

    @property
    def category(self):
        return self.equipment_type

    def __str__(self):
        category = self.equipment_type.name if self.equipment_type_id else "Uncategorised"
        return f"#{self.pk} · {category} · {self.customer_name}"




class PriceListCategory(models.Model):
    """A section of the official price list, kept separate from customer equipment categories."""
    name = models.CharField(max_length=160, unique=True)
    icon = models.CharField(max_length=10, default="🧰")
    sort_order = models.PositiveIntegerField(default=0)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ["sort_order", "name"]

    def __str__(self):
        return self.name


class PriceListItem(models.Model):
    """The authoritative repair/work catalogue used when a technician closes a job."""
    code = models.CharField(max_length=80, unique=True, null=True, blank=True)
    name_en = models.CharField(max_length=300)
    name_uz = models.CharField(max_length=300, blank=True, default="")
    name_uz_cyrl = models.CharField(max_length=300, blank=True, default="")
    name_ru = models.CharField(max_length=300, blank=True, default="")
    price = models.DecimalField(max_digits=12, decimal_places=2)
    unit = models.CharField(max_length=50, blank=True, default="")
    # Retained for compatibility with the earlier implementation. Official price-list
    # sections use price_category instead and do not affect customer equipment choices.
    equipment_type = models.ForeignKey(EquipmentType, null=True, blank=True, on_delete=models.SET_NULL, related_name="legacy_price_list_items")
    price_category = models.ForeignKey(PriceListCategory, null=True, blank=True, on_delete=models.SET_NULL, related_name="items")
    sort_order = models.PositiveIntegerField(default=0)
    active = models.BooleanField(default=True)

    class Meta:
        ordering = ["sort_order", "name_en"]

    def localized_name(self, language=None):
        language = language or "en"
        values = {
            "en": self.name_en,
            "uz": self.name_uz,
            "uz-cyrl": self.name_uz_cyrl,
            "ru": self.name_ru,
        }
        return values.get(language) or self.name_uz or self.name_uz_cyrl or self.name_ru or self.name_en

    def __str__(self):
        return f"{self.code + ' · ' if self.code else ''}{self.name_en}"


class ApplicationWork(models.Model):
    """A work item selected by the technician, with a price/name snapshot for auditability."""
    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name="completed_works")
    price_list_item = models.ForeignKey(PriceListItem, on_delete=models.PROTECT, related_name="application_works")
    quantity = models.PositiveIntegerField(default=1)
    price_snapshot = models.DecimalField(max_digits=12, decimal_places=2)
    name_snapshot_en = models.CharField(max_length=300)
    name_snapshot_uz = models.CharField(max_length=300, blank=True, default="")
    name_snapshot_uz_cyrl = models.CharField(max_length=300, blank=True, default="")
    name_snapshot_ru = models.CharField(max_length=300, blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["id"]
        constraints = [models.UniqueConstraint(fields=["application", "price_list_item"], name="core_appwork_app_item_uniq")]

    def localized_name(self, language=None):
        language = language or "en"
        values = {
            "en": self.name_snapshot_en,
            "uz": self.name_snapshot_uz,
            "uz-cyrl": self.name_snapshot_uz_cyrl,
            "ru": self.name_snapshot_ru,
        }
        return values.get(language) or self.name_snapshot_uz or self.name_snapshot_uz_cyrl or self.name_snapshot_ru or self.name_snapshot_en

    @property
    def total_price(self):
        return self.price_snapshot * self.quantity


class ApplicationEvent(models.Model):
    CREATED = "created"
    ASSIGNED = "assigned"
    STARTED = "started"
    COMPLETED = "completed"
    MARKED_URGENT = "marked_urgent"
    MARKED_SENSITIVE = "marked_sensitive"
    UNASSIGNED = "unassigned"
    NOTE_ADDED = "note_added"
    BLOCKED = "blocked"

    EVENT_CHOICES = [(x, x.replace("_", " ").title()) for x in (
        CREATED, ASSIGNED, STARTED, COMPLETED, MARKED_URGENT, MARKED_SENSITIVE,
        UNASSIGNED, NOTE_ADDED, BLOCKED
    )]
    application = models.ForeignKey(Application, on_delete=models.CASCADE, related_name="events")
    actor = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    event_type = models.CharField(max_length=30, choices=EVENT_CHOICES)
    notes = models.TextField(blank=True, default="")
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["application", "-created_at"], name="core_event_app_created_idx")]

    def __str__(self):
        return f"{self.event_type} · #{self.application_id}"


class Notification(models.Model):
    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="notifications")
    application = models.ForeignKey(Application, on_delete=models.CASCADE, null=True, blank=True, related_name="notifications")
    title = models.CharField(max_length=180)
    body = models.CharField(max_length=500, blank=True)
    read_at = models.DateTimeField(null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True, db_index=True)

    class Meta:
        ordering = ["-created_at"]
        indexes = [models.Index(fields=["user", "read_at", "-created_at"], name="core_note_user_read_idx")]
