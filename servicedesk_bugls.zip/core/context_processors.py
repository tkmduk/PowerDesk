from django.conf import settings


def language_choices(request):
    return {'LANGUAGES': settings.LANGUAGES}
