from django.conf import settings
from django.utils import translation


class AdminLanguageMiddleware:
    """Keep the Django admin English by default, independently of the public site language."""

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        if request.path.startswith('/admin/'):
            code = request.session.get('admin_language', settings.ADMIN_DEFAULT_LANGUAGE)
            if code not in {code for code, _ in settings.LANGUAGES}:
                code = settings.ADMIN_DEFAULT_LANGUAGE
            translation.activate(code)
            request.LANGUAGE_CODE = code
        response = self.get_response(request)
        if request.path.startswith('/admin/'):
            translation.deactivate()
        return response
