from django import template
from django.utils.translation import get_language

register = template.Library()

# Product UI copy. Keeping this map separate from database content means equipment,
# department and user-entered text remains untouched by interface translation.
T = {
    'uz': {
        'Sign in':'Kirish', 'Create account':'Hisob yaratish', 'Secure access':'Xavfsiz kirish', 'Welcome back.':'Xush kelibsiz.', 'New customer':'Yangi mijoz', 'Customer portal':'Mijoz portali', 'Your tools open according to your role.':'Asboblaringiz rolingizga qarab ochiladi.', 'See the status of your service request.':'Xizmat so‘rovingiz holatini ko‘ring.', 'Important service activity stays visible.':'Muhim xizmat faoliyati ko‘rinib turadi.', 'Built for clear, dependable service.':'Aniq va ishonchli xizmat uchun yaratilgan.', 'We could not sign you in.':'Kirish amalga oshmadi.', 'Required':'Majburiy', 'Hide':'Yashirish', 'Format: (99) 123 - 11 - 22':'Format: (99) 123 - 11 - 22', 'Use the same phone number registered by your organization or account.':'Tashkilotingiz yoki hisobingizda ro‘yxatdan o‘tgan telefon raqamidan foydalaning.', 'Already have an account?':'Allaqachon hisobingiz bormi?', 'Create your account once. After signing in, you can submit and track your own service requests.':'Hisobingizni bir marta yarating. Kirgandan so‘ng o‘z xizmat so‘rovlaringizni yuborishingiz va kuzatishingiz mumkin.', 'Simple enough for everyone.':'Hamma uchun sodda.', 'Create your account':'Hisobingizni yarating', 'Use your name and phone number.':'Ismingiz va telefon raqamingizdan foydalaning.', 'Sign in securely':'Xavfsiz kiring', 'Your role determines what you see.':'Rohingiz ko‘radigan ma’lumotlarni belgilaydi.', 'Track service':'Xizmatni kuzating', 'Follow requests from one place.':'So‘rovlarni bir joydan kuzating.', 'Full name':'To‘liq ism', 'Confirm password':'Parolni tasdiqlang', 'Minimum 8 characters.':'Kamida 8 ta belgi.', 'You can use your account to submit and follow service requests without choosing a technician yourself.':'Hisobingiz orqali texnik tanlamasdan xizmat so‘rovlarini yuborishingiz va kuzatishingiz mumkin.' ,
        'Every repair, routed right.':'Har bir ta’mir — to‘g‘ri mutaxassisga.',
        'One workspace for customers, dispatchers and technicians.':'Mijozlar, dispetcherlar va texniklar uchun yagona ish maydoni.',
        'Role-aware workspaces':'Rollar bo‘yicha ish maydonlari', 'Live request tracking':'So‘rovlarni jonli kuzatish',
        'Full audit trail':'To‘liq audit jurnali', 'Welcome back.':'Xush kelibsiz.',
        'Sign in with your Uzbekistan phone number. Your workspace opens automatically based on your role.':'O‘zbekiston telefon raqamingiz bilan kiring. Ish maydoni rolingizga qarab avtomatik ochiladi.',
        'Phone number':'Telefon raqami', 'Password':'Parol', 'Show':'Ko‘rsatish', 'Sign in':'Kirish',
        'New customer?':'Yangi mijozmisiz?', 'Create an account':'Hisob yaratish',
        'Create customer account':'Mijoz hisobini yaratish', 'Request service.':'Xizmat so‘rang.',
        'Request service':'Xizmat so‘rash', 'Customer portal':'Mijoz portali',
        'Need a technician?':'Texnik kerakmi?', 'Tell us what needs fixing.':'Nimani ta’mirlash kerakligini ayting.',
        'Your request goes to dispatch. You don’t need to choose a technician.':'So‘rovingiz dispetcherga yuboriladi. Texnikni o‘zingiz tanlashingiz shart emas.',
        'Requester name':'So‘rovchi ismi', 'Department':'Bo‘lim', 'Room / location':'Xona / joylashuv',
        'Internal phone':'Ichki telefon', 'Repair category':'Ta’mirlash toifasi', 'Problem description':'Muammo tavsifi',
        'Submit request':'So‘rov yuborish', 'YOUR REQUESTS':'SO‘ROVLARINGIZ', 'Submission history':'Yuborilgan so‘rovlar tarixi',
        'No requests yet':'Hali so‘rovlar yo‘q', 'Submit your first repair request above.':'Birinchi ta’mirlash so‘rovingizni yuqoridagi shakl orqali yuboring.',
        'Page':'Sahifa', 'Technician workspace':'Texnik ish maydoni', 'YOUR SPECIALIST DESK':'SIZNING MUTAXASSIS STOLINGIZ',
        'Stay focused on the repairs assigned to you.':'Sizga biriktirilgan ta’mirlash ishlariga e’tibor qarating.',
        'Only jobs dispatched to your certified categories appear here.':'Bu yerda faqat siz tasdiqlangan toifalarga tegishli ishlar ko‘rsatiladi.',
        'Active queue':'Faol navbat', 'In progress':'Jarayonda', 'Completed':'Tugallangan', 'Today':'Bugun',
        'assigned to you':'sizga biriktirilgan', 'being repaired now':'hozir ta’mirlanmoqda', 'all time':'butun davr', 'completed today':'bugun tugallangan',
        'Yesterday':'Kecha', '7 days':'7 kun', '30 days':'30 kun', 'completed':'tugallangan',
        '14-DAY RHYTHM':'14 KUNLIK FAOLLIK', 'Completed repairs':'Tugallangan ta’mirlar', 'LIVE QUEUE':'JONLI NAVBAT',
        'Current workload':'Joriy yuklama', 'Live':'Jonli', 'Nothing assigned right now.':'Hozircha hech narsa biriktirilmagan.',
        'ACTION QUEUE':'HARAKATLAR NAVBATI', 'Assigned repairs':'Biriktirilgan ta’mirlar', 'Start repair →':'Ta’mirlashni boshlash →',
        'Complete job ✓':'Ishni tugatish ✓', 'Queue clear':'Navbat bo‘sh', 'When dispatch assigns a repair to you, it will appear here.':'Dispetcher sizga ish biriktirganda, u shu yerda paydo bo‘ladi.',
        'HISTORY':'TARIX', 'Completed work':'Tugallangan ishlar', 'Done':'Tayyor', 'No completed jobs yet.':'Hali tugallangan ishlar yo‘q.',
        'Dispatch command center':'Dispetcher boshqaruv markazi', 'Urgent now':'Hozir shoshilinch', 'needs attention':'e’tibor talab qiladi',
        'Unassigned':'Biriktirilmagan', 'waiting for dispatch':'dispetcherni kutmoqda', 'Completed today':'Bugun tugallangan', 'closed successfully':'muvaffaqiyatli yopilgan',
        'WORKFORCE MAP':'XODIMLAR XARITASI', 'Who is doing what':'Kim nima bilan shug‘ullanmoqda', 'Auto refresh':'Avtomatik yangilash',
        'No active workers.':'Faol texniklar yo‘q.', 'DISPATCH LOGIC':'DISPETCHER QOIDALARI', 'Assign by category, then workload.':'Avval toifa, keyin yuklama bo‘yicha biriktiring.',
        'Only technicians certified for the request category are available. Use workload as the tie-breaker so the queue stays balanced.':'Faqat so‘rov toifasi bo‘yicha malakali texniklar mavjud. Navbatni muvozanatda saqlash uchun yuklamani mezon sifatida ishlating.',
        'Category protected':'Toifa himoyalangan', 'Active workload visible':'Faol yuklama ko‘rinadi', 'Full audit trail':'To‘liq audit jurnali',
        'REQUEST FLOW':'SO‘ROV OQIMI', 'All service requests':'Barcha xizmat so‘rovlari', 'Search ID, customer, room…':'ID, mijoz, xona bo‘yicha qidiring…',
        'Active':'Faol', 'Waiting':'Kutilmoqda', 'Assigned':'Biriktirilgan', 'Completed':'Tugallangan', 'Filter':'Filtrlash',
        'Assign specialist…':'Mutaxassisni biriktiring…', 'Reassign':'Qayta biriktirish', 'Dispatch':'Biriktirish',
        'Super admin':'Super administrator', 'Executive command center':'Ijrochi boshqaruv markazi', 'Everything important, one screen.':'Muhim narsalarning barchasi — bir ekranda.',
        'Manage people, monitor service performance, tune operational rules and inspect the audit trail.':'Xodimlarni boshqaring, xizmat samaradorligini kuzating, operatsion qoidalarni sozlang va audit jurnalini ko‘ring.',
        'Add staff':'Xodim qo‘shish', 'Analytics →':'Analitika →', 'All users':'Barcha foydalanuvchilar', 'Customers':'Mijozlar',
        'Workers':'Texniklar', 'Dispatchers':'Dispetcherlar', 'Open work':'Ochiq ishlar', 'Urgent':'Shoshilinch', 'New today':'Bugun yangi',
        'excluding super admins':'super administratorlarsiz', 'service users':'xizmat foydalanuvchilari', 'active specialists':'faol mutaxassislar',
        'active coordinators':'faol koordinatorlar', 'not completed':'tugallanmagan', 'requires attention':'e’tibor talab qiladi', 'requests submitted':'yuborilgan so‘rovlar',
        'WORKLOAD':'YUKLAMA', 'Current worker load':'Texniklarning joriy yuklamasi', 'No active workload.':'Faol yuklama yo‘q.',
        'OPERATIONAL RULES':'OPERATSION QOIDALAR', 'System controls':'Tizim boshqaruvlari', 'Rule name':'Qoida nomi', 'Value':'Qiymat',
        'What does this control?':'Bu boshqaruv nima qiladi?', 'Add rule':'Qoida qo‘shish', 'Save':'Saqlash', 'No custom rules yet. Add operational limits here.':'Maxsus qoidalar yo‘q. Operatsion cheklovlarni shu yerda qo‘shing.',
        'PEOPLE & ACCESS':'XODIMLAR VA KIRISH', 'Manage everyone':'Barchani boshqarish', 'Search name or phone':'Ism yoki telefon bo‘yicha qidiring',
        'All roles':'Barcha rollar', 'Edit':'Tahrirlash', 'Block':'Bloklash', 'Unblock':'Blokdan chiqarish', 'Reset':'Tiklash', 'Confirm':'Tasdiqlash', 'No users found.':'Foydalanuvchilar topilmadi.',
        'AUDIT TRAIL':'AUDIT JURNALI', 'Latest system events':'So‘nggi tizim hodisalari', 'System event':'Tizim hodisasi', 'No events yet.':'Hali hodisalar yo‘q.',
        'Analytics':'Analitika', 'Worker performance':'Texniklar samaradorligi', 'PERFORMANCE OVERVIEW':'SAMARADORLIK KO‘RINISHI',
        'See who is carrying the queue.':'Navbat yuklamasini ko‘ring.', 'Compare active workload and completed repairs across today, this week and this month.':'Bugun, shu hafta va shu oy bo‘yicha faol yuklama hamda tugallangan ta’mirlarni solishtiring.',
        'active':'faol', 'today':'bugun', '7 days':'7 kun', '30 days':'30 kun', 'No workers configured.':'Texniklar sozlanmagan.',
        'Add a worker or dispatcher':'Texnik yoki dispetcher qo‘shish', 'Update':'Yangilash', 'Workers must have at least one repair category. Dispatchers do not need a specialization.':'Texnik kamida bitta ta’mirlash toifasiga ega bo‘lishi kerak. Dispetcherga mutaxassislik shart emas.',
        'Role':'Rol', 'Account status':'Hisob holati', 'Active account':'Faol hisob', 'Worker specializations':'Texnik mutaxassisliklari', 'Cancel':'Bekor qilish', 'Save account →':'Hisobni saqlash →',
        'Protected workspace':'Himoyalangan ish maydoni', 'Command center':'Boshqaruv markazi', 'All requests':'Barcha so‘rovlar', 'Dispatch board':'Dispetcher paneli', 'My workspace':'Mening ish maydonim', 'New request':'Yangi so‘rov', 'Sign out':'Chiqish',
        'Language':'Til', 'English':'English', 'O‘zbek (Latin)':'O‘zbek (Latin)', 'Ўзбек (Кирилл)':'Ўзбек (Кирилл)', 'Русский':'Русский',
    },
    'ru': {
        'Sign in':'Войти', 'Create account':'Создать аккаунт', 'Secure access':'Безопасный доступ', 'Welcome back.':'С возвращением.', 'New customer':'Новый клиент', 'Customer portal':'Портал клиента', 'Your tools open according to your role.':'Инструменты открываются в соответствии с вашей ролью.', 'See the status of your service request.':'Следите за статусом вашей заявки.', 'Important service activity stays visible.':'Важные действия по заявке остаются видимыми.', 'Built for clear, dependable service.':'Для понятного и надёжного сервиса.', 'We could not sign you in.':'Не удалось выполнить вход.', 'Required':'Обязательно', 'Hide':'Скрыть', 'Format: (99) 123 - 11 - 22':'Формат: (99) 123 - 11 - 22', 'Use the same phone number registered by your organization or account.':'Используйте номер телефона, зарегистрированный вашей организацией или аккаунтом.', 'Already have an account?':'Уже есть аккаунт?', 'Create your account once. After signing in, you can submit and track your own service requests.':'Создайте аккаунт один раз. После входа вы сможете отправлять и отслеживать свои заявки.', 'Simple enough for everyone.':'Просто для каждого.', 'Create your account':'Создайте аккаунт', 'Use your name and phone number.':'Укажите имя и номер телефона.', 'Sign in securely':'Войдите безопасно', 'Your role determines what you see.':'Ваша роль определяет доступную информацию.', 'Track service':'Отслеживайте сервис', 'Follow requests from one place.':'Следите за заявками в одном месте.', 'Full name':'Полное имя', 'Confirm password':'Подтвердите пароль', 'Minimum 8 characters.':'Минимум 8 символов.', 'You can use your account to submit and follow service requests without choosing a technician yourself.':'Используйте аккаунт, чтобы отправлять и отслеживать заявки, не выбирая техника самостоятельно.', 'Every repair, routed right.':'Каждая заявка — правильному специалисту.',
        'One workspace for customers, dispatchers and technicians.':'Единое рабочее пространство для клиентов, диспетчеров и техников.', 'Role-aware workspaces':'Рабочие пространства по ролям', 'Live request tracking':'Отслеживание заявок в реальном времени', 'Full audit trail':'Полный журнал аудита',
        'Welcome back.':'С возвращением.', 'Sign in with your Uzbekistan phone number. Your workspace opens automatically based on your role.':'Войдите с номером телефона Узбекистана. Рабочее пространство откроется автоматически по вашей роли.',
        'Phone number':'Номер телефона', 'Password':'Пароль', 'Show':'Показать', 'New customer?':'Новый клиент?', 'Create an account':'Создать аккаунт',
        'Create customer account':'Создание аккаунта клиента', 'Request service.':'Оставьте заявку.', 'Request service':'Заказать услугу', 'Customer portal':'Портал клиента',
        'Need a technician?':'Нужен техник?', 'Tell us what needs fixing.':'Расскажите, что нужно исправить.', 'Your request goes to dispatch. You don’t need to choose a technician.':'Заявка отправится диспетчеру. Вам не нужно выбирать техника.',
        'Requester name':'Имя заявителя', 'Department':'Отдел', 'Room / location':'Кабинет / место', 'Internal phone':'Внутренний телефон', 'Repair category':'Категория ремонта', 'Problem description':'Описание проблемы', 'Submit request':'Отправить заявку',
        'YOUR REQUESTS':'ВАШИ ЗАЯВКИ', 'Submission history':'История заявок', 'No requests yet':'Заявок пока нет', 'Submit your first repair request above.':'Отправьте первую заявку через форму выше.', 'Page':'Страница',
        'Technician workspace':'Рабочее место техника', 'YOUR SPECIALIST DESK':'ВАШЕ РАБОЧЕЕ МЕСТО', 'Stay focused on the repairs assigned to you.':'Сосредоточьтесь на назначенных вам ремонтах.', 'Only jobs dispatched to your certified categories appear here.':'Здесь отображаются только работы по вашим подтверждённым категориям.',
        'Active queue':'Активная очередь', 'In progress':'В работе', 'Completed':'Завершено', 'Today':'Сегодня', 'assigned to you':'назначено вам', 'being repaired now':'ремонтируется сейчас', 'all time':'за всё время', 'completed today':'завершено сегодня',
        'Yesterday':'Вчера', '7 days':'7 дней', '30 days':'30 дней', 'completed':'завершено', 'Completed repairs':'Завершённые ремонты', 'Current workload':'Текущая нагрузка', 'Live':'Онлайн', 'Nothing assigned right now.':'Сейчас ничего не назначено.',
        'Assigned repairs':'Назначенные ремонты', 'Start repair →':'Начать ремонт →', 'Complete job ✓':'Завершить работу ✓', 'Queue clear':'Очередь пуста', 'When dispatch assigns a repair to you, it will appear here.':'Когда диспетчер назначит вам ремонт, он появится здесь.', 'Completed work':'Завершённые работы', 'Done':'Готово', 'No completed jobs yet.':'Завершённых работ пока нет.',
        'Urgent now':'Срочно', 'needs attention':'требует внимания', 'Unassigned':'Не назначено', 'waiting for dispatch':'ожидает диспетчера', 'Completed today':'Завершено сегодня', 'closed successfully':'успешно закрыто', 'Who is doing what':'Кто чем занимается', 'Auto refresh':'Автообновление', 'No active workers.':'Нет активных техников.',
        'Assign by category, then workload.':'Назначайте сначала по категории, затем по нагрузке.', 'Category protected':'Категория защищена', 'Active workload visible':'Нагрузка видна', 'Full audit trail':'Полный журнал аудита', 'All service requests':'Все заявки', 'Filter':'Фильтр', 'Waiting':'Ожидание', 'Assigned':'Назначено', 'Assign specialist…':'Назначить специалиста…', 'Reassign':'Переназначить', 'Dispatch':'Назначить',
        'Executive command center':'Центр управления', 'Everything important, one screen.':'Всё важное — на одном экране.', 'Manage people, monitor service performance, tune operational rules and inspect the audit trail.':'Управляйте сотрудниками, контролируйте качество сервиса, настраивайте правила и просматривайте аудит.', 'Add staff':'Добавить сотрудника', 'Analytics →':'Аналитика →',
        'All users':'Все пользователи', 'Customers':'Клиенты', 'Workers':'Техники', 'Dispatchers':'Диспетчеры', 'Open work':'Открытые работы', 'Urgent':'Срочные', 'New today':'Новые сегодня', 'excluding super admins':'без супер-администраторов', 'service users':'пользователи сервиса', 'active specialists':'активные специалисты', 'active coordinators':'активные координаторы', 'not completed':'не завершено', 'requires attention':'требует внимания', 'requests submitted':'подано заявок',
        'Current worker load':'Текущая нагрузка техников', 'No active workload.':'Нет активной нагрузки.', 'System controls':'Управление системой', 'Rule name':'Название правила', 'Value':'Значение', 'What does this control?':'Что контролирует это правило?', 'Add rule':'Добавить правило', 'Save':'Сохранить', 'No custom rules yet. Add operational limits here.':'Пользовательских правил пока нет.',
        'Manage everyone':'Управление пользователями', 'Search name or phone':'Поиск по имени или телефону', 'All roles':'Все роли', 'Edit':'Изменить', 'Block':'Заблокировать', 'Unblock':'Разблокировать', 'Reset':'Сбросить', 'No users found.':'Пользователи не найдены.', 'Latest system events':'Последние события системы', 'System event':'Системное событие', 'No events yet.':'Событий пока нет.',
        'Worker performance':'Производительность техников', 'See who is carrying the queue.':'Посмотрите распределение нагрузки.', 'Compare active workload and completed repairs across today, this week and this month.':'Сравнивайте активную нагрузку и завершённые ремонты за сегодня, неделю и месяц.', 'No workers configured.':'Техники не настроены.',
        'Add a worker or dispatcher':'Добавить техника или диспетчера', 'Update':'Обновить', 'Workers must have at least one repair category. Dispatchers do not need a specialization.':'Техник должен иметь хотя бы одну категорию ремонта. Диспетчеру специализация не нужна.', 'Role':'Роль', 'Account status':'Статус аккаунта', 'Active account':'Активный аккаунт', 'Worker specializations':'Специализации техника', 'Cancel':'Отмена', 'Save account →':'Сохранить аккаунт →',
        'Protected workspace':'Защищённое рабочее пространство', 'Command center':'Центр управления', 'All requests':'Все заявки', 'Dispatch board':'Панель диспетчера', 'My workspace':'Моё рабочее место', 'New request':'Новая заявка', 'Sign out':'Выйти',
        'Language':'Язык', 'English':'English', 'O‘zbek (Latin)':'O‘zbek (Latin)', 'Ўзбек (Кирилл)':'Ўзбек (Кирилл)', 'Русский':'Русский',
    },
    'uz-cyrl': {
        'Sign in':'Кириш', 'Create account':'Ҳисоб яратиш', 'Secure access':'Хавфсиз кириш', 'Welcome back.':'Хуш келибсиз.', 'New customer':'Янги мижоз', 'Customer portal':'Мижоз портали', 'Your tools open according to your role.':'Асбобларингиз ролиңизга қараб очилади.', 'See the status of your service request.':'Хизмат сўровингиз ҳолатини кўринг.', 'Important service activity stays visible.':'Муҳим хизмат фаолияти кўриниб туради.', 'Built for clear, dependable service.':'Аниқ ва ишончли хизмат учун яратилган.', 'We could not sign you in.':'Кириш амалга ошмади.', 'Required':'Мажбурий', 'Hide':'Яшириш', 'Format: (99) 123 - 11 - 22':'Формат: (99) 123 - 11 - 22', 'Use the same phone number registered by your organization or account.':'Ташкилотингиз ёки ҳисобингизда рўйхатдан ўтган телефон рақамидан фойдаланинг.', 'Already have an account?':'Аллақачон ҳисобингиз борми?', 'Create your account once. After signing in, you can submit and track your own service requests.':'Ҳисобингизни бир марта яратинг. Киргандан сўнг ўз хизмат сўровларингизни юборишингиз ва кузатишингиз мумкин.', 'Simple enough for everyone.':'Ҳамма учун содда.', 'Create your account':'Ҳисобингизни яратинг', 'Use your name and phone number.':'Исмингиз ва телефон рақамингиздан фойдаланинг.', 'Sign in securely':'Хавфсиз киринг', 'Your role determines what you see.':'Ролингиз кўрадиган маълумотларни белгилайди.', 'Track service':'Хизматни кузатинг', 'Follow requests from one place.':'Сўровларни бир жойдан кузатинг.', 'Full name':'Тўлиқ исм', 'Confirm password':'Паролни тасдиқланг', 'Minimum 8 characters.':'Камида 8 та белги.', 'You can use your account to submit and follow service requests without choosing a technician yourself.':'Ҳисобингиз орқали техник танламасдан хизмат сўровларини юборишингиз ва кузатишингиз мумкин.', 'Every repair, routed right.':'Ҳар бир таъмир — тўғри мутахассисга.',
        'One workspace for customers, dispatchers and technicians.':'Мижозлар, диспетчерлар ва техниклар учун ягона иш майдони.', 'Role-aware workspaces':'Роллар бўйича иш майдонлари', 'Live request tracking':'Сўровларни жонли кузатиш', 'Full audit trail':'Тўлиқ аудит журнали',
        'Welcome back.':'Хуш келибсиз.', 'Sign in with your Uzbekistan phone number. Your workspace opens automatically based on your role.':'Ўзбекистон телефон рақамингиз билан киринг. Иш майдонингиз ролиңизга қараб автоматик очилади.',
        'Phone number':'Телефон рақами', 'Password':'Парол', 'Show':'Кўрсатиш', 'New customer?':'Янги мижозмисиз?', 'Create an account':'Ҳисоб яратиш',
        'Create customer account':'Мижоз ҳисобини яратиш', 'Request service.':'Хизмат сўранг.', 'Request service':'Хизмат сўраш', 'Customer portal':'Мижоз портали',
        'Need a technician?':'Техник керакми?', 'Tell us what needs fixing.':'Нимани таъмирлаш кераклигини айтинг.', 'Your request goes to dispatch. You don’t need to choose a technician.':'Сўровингиз диспетчерга юборилади. Техникни ўзингиз танлашингиз шарт эмас.',
        'Requester name':'Сўровчи исми', 'Department':'Бўлим', 'Room / location':'Хона / жойлашув', 'Internal phone':'Ички телефон', 'Repair category':'Таъмирлаш тоифаси', 'Problem description':'Муаммо тавсифи', 'Submit request':'Сўров юбориш',
        'YOUR REQUESTS':'СЎРОВЛАРИНГИЗ', 'Submission history':'Юборилган сўровлар тарихи', 'No requests yet':'Ҳали сўровлар йўқ', 'Submit your first repair request above.':'Биринчи таъмирлаш сўровингизни юқоридаги шакл орқали юборинг.', 'Page':'Саҳифа',
        'Technician workspace':'Техник иш майдони', 'YOUR SPECIALIST DESK':'СИЗНИНГ МУТАХАССИС ИШ МАЙДОНИНГИЗ', 'Stay focused on the repairs assigned to you.':'Сизга бириктирилган таъмирлаш ишларига эътибор қаратинг.', 'Only jobs dispatched to your certified categories appear here.':'Бу ерда фақат сиз тасдиқланган тоифаларга тегишли ишлар кўрсатилади.',
        'Active queue':'Фаол навбат', 'In progress':'Жараёнда', 'Completed':'Тугалланган', 'Today':'Бугун', 'assigned to you':'сизга бириктирилган', 'being repaired now':'ҳозир таъмирланмоқда', 'all time':'бутун давр', 'completed today':'бугун тугалланган',
        'Yesterday':'Кеча', '7 days':'7 кун', '30 days':'30 кун', 'completed':'тугалланган', 'Completed repairs':'Тугалланган таъмирлар', 'Current workload':'Жорий юклама', 'Live':'Жонли', 'Nothing assigned right now.':'Ҳозирча ҳеч нарса бириктирилмаган.',
        'Assigned repairs':'Бириктирилган таъмирлар', 'Start repair →':'Таъмирлашни бошлаш →', 'Complete job ✓':'Ишни тугатиш ✓', 'Queue clear':'Навбат бўш', 'When dispatch assigns a repair to you, it will appear here.':'Диспетчер сизга иш бириктирганда, у шу ерда пайдо бўлади.', 'Completed work':'Тугалланган ишлар', 'Done':'Тайёр', 'No completed jobs yet.':'Ҳали тугалланган ишлар йўқ.',
        'Urgent now':'Ҳозир шошилинч', 'needs attention':'эътибор талаб қилади', 'Unassigned':'Бириктирилмаган', 'waiting for dispatch':'диспетчерни кутмоқда', 'Completed today':'Бугун тугалланган', 'closed successfully':'муваффақиятли ёпилган', 'Who is doing what':'Ким нима билан шуғулланмоқда', 'Auto refresh':'Автоматик янгилаш', 'No active workers.':'Фаол техниклар йўқ.',
        'Assign by category, then workload.':'Аввал тоифа, кейин юклама бўйича бириктиринг.', 'Category protected':'Тоифа ҳимояланган', 'Active workload visible':'Фаол юклама кўринади', 'Full audit trail':'Тўлиқ аудит журнали', 'All service requests':'Барча хизмат сўровлари', 'Filter':'Филтр', 'Waiting':'Кутилмоқда', 'Assigned':'Бириктирилган', 'Assign specialist…':'Мутахассисни бириктиринг…', 'Reassign':'Қайта бириктириш', 'Dispatch':'Бириктириш',
        'Executive command center':'Ижрочи бошқарув маркази', 'Everything important, one screen.':'Муҳим нарсаларнинг барчаси — бир экранда.', 'Manage people, monitor service performance, tune operational rules and inspect the audit trail.':'Ходимларни бошқаринг, хизмат самарадорлигини кузатинг, операцион қоидаларни созланг ва аудит журналини кўринг.', 'Add staff':'Ходим қўшиш', 'Analytics →':'Аналитика →',
        'All users':'Барча фойдаланувчилар', 'Customers':'Мижозлар', 'Workers':'Техниклар', 'Dispatchers':'Диспетчерлар', 'Open work':'Очиқ ишлар', 'Urgent':'Шошилинч', 'New today':'Бугун янги', 'excluding super admins':'супер администраторларсиз', 'service users':'хизмат фойдаланувчилари', 'active specialists':'фаол мутахассислар', 'active coordinators':'фаол координаторлар', 'not completed':'тугалланмаган', 'requires attention':'эътибор талаб қилади', 'requests submitted':'юборилган сўровлар',
        'Current worker load':'Техникларнинг жорий юкламаси', 'No active workload.':'Фаол юклама йўқ.', 'System controls':'Тизим бошқарувлари', 'Rule name':'Қоида номи', 'Value':'Қиймат', 'What does this control?':'Бу бошқарув нима қилади?', 'Add rule':'Қоида қўшиш', 'Save':'Сақлаш', 'No custom rules yet. Add operational limits here.':'Махсус қоидалар йўқ. Операцион чекловларни шу ерда қўшинг.',
        'Manage everyone':'Барчани бошқариш', 'Search name or phone':'Исм ёки телефон бўйича қидириш', 'All roles':'Барча роллар', 'Edit':'Таҳрирлаш', 'Block':'Блоклаш', 'Unblock':'Блокдан чиқариш', 'Reset':'Тиклаш', 'No users found.':'Фойдаланувчилар топилмади.', 'Latest system events':'Сўнгги тизим ҳодисалари', 'System event':'Тизим ҳодисаси', 'No events yet.':'Ҳали ҳодисалар йўқ.',
        'Worker performance':'Техниклар самарадорлиги', 'See who is carrying the queue.':'Навбат юкламасини кўринг.', 'Compare active workload and completed repairs across today, this week and this month.':'Бугун, шу ҳафта ва шу ой бўйича фаол юклама ҳамда тугалланган таъмирларни солиштиринг.', 'No workers configured.':'Техниклар созланмаган.',
        'Add a worker or dispatcher':'Техник ёки диспетчер қўшиш', 'Update':'Янгилаш', 'Workers must have at least one repair category. Dispatchers do not need a specialization.':'Техник камида битта таъмирлаш тоифасига эга бўлиши керак. Диспетчерга мутахассислик шарт эмас.', 'Role':'Рол', 'Account status':'Ҳисоб ҳолати', 'Active account':'Фаол ҳисоб', 'Worker specializations':'Техник мутахассисликлари', 'Cancel':'Бекор қилиш', 'Save account →':'Ҳисобни сақлаш →',
        'Protected workspace':'Ҳимояланган иш майдони', 'Command center':'Бошқарув маркази', 'All requests':'Барча сўровлар', 'Dispatch board':'Диспетчер панели', 'My workspace':'Менинг иш майдоним', 'New request':'Янги сўров', 'Sign out':'Чиқиш',
        'Language':'Тил', 'English':'English', 'O‘zbek (Latin)':'O‘zbek (Latin)', 'Ўзбек (Кирилл)':'Ўзбек (Кирилл)', 'Русский':'Русский',
    }
}

# Workflow copy added for the technician completion and customer approval flow.
T_EXTRA = {
    "en": {
        "Waiting for customer approval":"Waiting for customer approval", "Correction requested":"Correction requested",
        "Submit completion report":"Submit completion report", "Select every work performed":"Select every work performed",
        "Choose all repair works you actually completed. The customer will see the names, but not prices.":"Choose all repair works you actually completed. The customer will see the names, but not prices.",
        "Price list":"Price list", "Photo of completed work":"Photo of completed work", "Take photo":"Take photo",
        "Completion note":"Completion note", "Submit for customer approval":"Submit for customer approval",
        "Customer approval":"Customer approval", "Review completed work":"Review completed work",
        "The technician says this work is complete.":"The technician says this work is complete.",
        "Work completed":"Work completed", "No price is shown here.":"No price is shown here.",
        "Approve completed work":"Approve completed work", "Request correction":"Request correction",
        "Optional note about this approval":"Optional note about this approval", "What needs correction?":"What needs correction?",
        "Tell the technician what is still missing or needs fixing.":"Tell the technician what is still missing or needs fixing.",
        "Technician proof photo":"Technician proof photo", "Completion report":"Completion report",
        "Worker":"Worker", "Customer":"Customer", "Phone":"Phone", "Room":"Room",
        "Total price":"Total price", "Work item":"Work item", "Unit price":"Unit price", "Qty":"Qty",
        "Report details":"Report details", "Customer approved":"Customer approved", "Not approved yet":"Not approved yet",
        "Waiting approval":"Waiting approval", "Correction":"Correction", "View full report":"View full report",
        "No completion reports yet":"No completion reports yet", "Price list is not loaded yet":"Price list is not loaded yet",
        "Ask an administrator to import the official price list before completing jobs.":"Ask an administrator to import the official price list before completing jobs.",
        "Resume repair":"Resume repair", "Correction from customer":"Correction from customer",
        "Take a clear photo of the completed work. Maximum 10 MB.":"Take a clear photo of the completed work. Maximum 10 MB.",
        "Approve":"Approve", "Needs correction":"Needs correction", "Customer approved this repair":"Customer approved this repair",
        "Job reports":"Job reports", "Waiting for approval":"Waiting for approval", "Price list items":"Price list items", "The customer will receive the selected work names and your photo. Prices remain internal.":"The customer will receive the selected work names and your photo. Prices remain internal.",
    },
    "uz": {
        "Waiting for customer approval":"Mijoz tasdig‘ini kutmoqda", "Correction requested":"Tuzatish so‘ralgan",
        "Submit completion report":"Yakuniy hisobotni yuborish", "Select every work performed":"Bajarilgan barcha ishlarni tanlang",
        "Choose all repair works you actually completed. The customer will see the names, but not prices.":"Haqiqatan bajargan barcha ta’mirlash ishlaringizni tanlang. Mijoz ish nomlarini ko‘radi, lekin narxlarni ko‘rmaydi.",
        "Price list":"Narxlar ro‘yxati", "Photo of completed work":"Bajarilgan ish fotosurati", "Take photo":"Suratga olish",
        "Completion note":"Yakuniy izoh", "Submit for customer approval":"Mijoz tasdig‘iga yuborish",
        "Customer approval":"Mijoz tasdig‘i", "Review completed work":"Bajarilgan ishni tekshiring",
        "The technician says this work is complete.":"Texnik bu ish tugaganini bildirgan.", "Work completed":"Bajarilgan ishlar", "No price is shown here.":"Bu yerda narx ko‘rsatilmaydi.",
        "Approve completed work":"Bajarilgan ishni tasdiqlash", "Request correction":"Tuzatish so‘rash", "Optional note about this approval":"Tasdiq uchun ixtiyoriy izoh",
        "What needs correction?":"Nimani tuzatish kerak?", "Tell the technician what is still missing or needs fixing.":"Hali nima yetishmayotgani yoki nimani tuzatish kerakligini texnikka yozing.",
        "Technician proof photo":"Texnikning dalil fotosurati", "Completion report":"Yakuniy hisobot", "Worker":"Texnik", "Customer":"Mijoz", "Phone":"Telefon", "Room":"Xona",
        "Total price":"Jami narx", "Work item":"Ish turi", "Unit price":"Birlik narxi", "Qty":"Soni", "Report details":"Hisobot tafsilotlari",
        "Customer approved":"Mijoz tasdiqlagan", "Not approved yet":"Hali tasdiqlanmagan", "Waiting approval":"Tasdiq kutilmoqda", "Correction":"Tuzatish", "View full report":"To‘liq hisobotni ko‘rish",
        "No completion reports yet":"Hali yakuniy hisobotlar yo‘q", "Price list is not loaded yet":"Narxlar ro‘yxati hali yuklanmagan", "Ask an administrator to import the official price list before completing jobs.":"Ishni yakunlashdan oldin administrator rasmiy narxlar ro‘yxatini import qilishi kerak.",
        "Resume repair":"Ta’mirlashni davom ettirish", "Correction from customer":"Mijozdan tuzatish so‘rovi", "Take a clear photo of the completed work. Maximum 10 MB.":"Bajarilgan ishning aniq suratini oling. Maksimum 10 MB.",
        "Approve":"Tasdiqlash", "Needs correction":"Tuzatish kerak", "Customer approved this repair":"Mijoz bu ta’mirni tasdiqladi", "Job reports":"Ish hisobotlari", "Waiting for approval":"Tasdiq kutilmoqda", "Price list items":"Narxlar ro‘yxati", "The customer will receive the selected work names and your photo. Prices remain internal.":"Mijoz tanlangan ish nomlari va suratingizni ko‘radi. Narxlar ichki ma’lumot bo‘lib qoladi.",
    },
    "uz-cyrl": {
        "Waiting for customer approval":"Мижоз тасдиғини кутмоқда", "Correction requested":"Тузатиш сўралган", "Submit completion report":"Якуний ҳисоботни юбориш",
        "Select every work performed":"Бажарилган барча ишларни танланг", "Choose all repair works you actually completed. The customer will see the names, but not prices.":"Ҳақиқатан бажарган барча таъмирлаш ишларингизни танланг. Мижоз иш номларини кўради, лекин нархларни кўрмайди.",
        "Price list":"Нархлар рўйхати", "Photo of completed work":"Бажарилган иш сурати", "Take photo":"Суратга олиш", "Completion note":"Якуний изоҳ", "Submit for customer approval":"Мижоз тасдиғига юбориш",
        "Customer approval":"Мижоз тасдиғи", "Review completed work":"Бажарилган ишни текширинг", "The technician says this work is complete.":"Техник бу иш тугаганини билдирган.", "Work completed":"Бажарилган ишлар", "No price is shown here.":"Бу ерда нарх кўрсатилмайди.",
        "Approve completed work":"Бажарилган ишни тасдиқлаш", "Request correction":"Тузатиш сўраш", "Optional note about this approval":"Тасдиқ учун ихтиёрий изоҳ", "What needs correction?":"Нимани тузатиш керак?",
        "Tell the technician what is still missing or needs fixing.":"Ҳали нима етишмаётгани ёки нимани тузатиш кераклигини техникка ёзинг.", "Technician proof photo":"Техникнинг далил сурати", "Completion report":"Якуний ҳисобот",
        "Worker":"Техник", "Customer":"Мижоз", "Phone":"Телефон", "Room":"Хона", "Total price":"Жами нарх", "Work item":"Иш тури", "Unit price":"Бирлик нархи", "Qty":"Сони", "Report details":"Ҳисобот тафсилотлари",
        "Customer approved":"Мижоз тасдиқлаган", "Not approved yet":"Ҳали тасдиқланмаган", "Waiting approval":"Тасдиқ кутилмоқда", "Correction":"Тузатиш", "View full report":"Тўлиқ ҳисоботни кўриш",
        "No completion reports yet":"Ҳали якуний ҳисоботлар йўқ", "Price list is not loaded yet":"Нархлар рўйхати ҳали юкланмаган", "Ask an administrator to import the official price list before completing jobs.":"Ишни якунлашдан олдин администратор расмий нархлар рўйхатини импорт қилиши керак.",
        "Resume repair":"Таъмирлашни давом эттириш", "Correction from customer":"Мижоздан тузатиш сўрови", "Take a clear photo of the completed work. Maximum 10 MB.":"Бажарилган ишнинг аниқ суратини олинг. Максимум 10 МБ.",
        "Approve":"Тасдиқлаш", "Needs correction":"Тузатиш керак", "Customer approved this repair":"Мижоз бу таъмирни тасдиқлади", "Job reports":"Иш ҳисоботлари", "Waiting for approval":"Тасдиқ кутилмоқда", "Price list items":"Нархлар рўйхати", "The customer will receive the selected work names and your photo. Prices remain internal.":"Мижоз танланган иш номлари ва суратингизни кўради. Нархлар ички маълумот бўлиб қолади.",
    },
    "ru": {
        "Waiting for customer approval":"Ожидает подтверждения клиента", "Correction requested":"Запрошено исправление", "Submit completion report":"Отправить отчёт о выполнении", "Select every work performed":"Выберите все выполненные работы",
        "Choose all repair works you actually completed. The customer will see the names, but not prices.":"Выберите все работы, которые были фактически выполнены. Клиент увидит названия, но не цены.", "Price list":"Прайс-лист", "Photo of completed work":"Фото выполненной работы", "Take photo":"Сделать фото",
        "Completion note":"Комментарий о выполнении", "Submit for customer approval":"Отправить на подтверждение клиента", "Customer approval":"Подтверждение клиента", "Review completed work":"Проверьте выполненную работу",
        "The technician says this work is complete.":"Техник сообщил, что работа выполнена.", "Work completed":"Выполненные работы", "No price is shown here.":"Цена здесь не показывается.", "Approve completed work":"Подтвердить выполненную работу", "Request correction":"Запросить исправление",
        "Optional note about this approval":"Необязательный комментарий к подтверждению", "What needs correction?":"Что нужно исправить?", "Tell the technician what is still missing or needs fixing.":"Укажите технику, что ещё не сделано или требует исправления.",
        "Technician proof photo":"Фото-доказательство техника", "Completion report":"Отчёт о выполнении", "Worker":"Техник", "Customer":"Клиент", "Phone":"Телефон", "Room":"Кабинет", "Total price":"Итоговая цена", "Work item":"Работа", "Unit price":"Цена за единицу", "Qty":"Кол-во",
        "Report details":"Детали отчёта", "Customer approved":"Клиент подтвердил", "Not approved yet":"Пока не подтверждено", "Waiting approval":"Ожидает подтверждения", "Correction":"Исправление", "View full report":"Открыть полный отчёт", "No completion reports yet":"Отчётов о выполнении пока нет",
        "Price list is not loaded yet":"Прайс-лист пока не загружен", "Ask an administrator to import the official price list before completing jobs.":"Попросите администратора импортировать официальный прайс-лист до завершения работ.", "Resume repair":"Продолжить ремонт", "Correction from customer":"Запрос клиента на исправление", "Take a clear photo of the completed work. Maximum 10 MB.":"Сделайте чёткое фото выполненной работы. Максимум 10 МБ.",
        "Approve":"Подтвердить", "Needs correction":"Нужна корректировка", "Customer approved this repair":"Клиент подтвердил этот ремонт", "Job reports":"Отчёты по работам", "Waiting for approval":"Ожидает подтверждения", "Price list items":"Позиции прайс-листа", "The customer will receive the selected work names and your photo. Prices remain internal.":"Клиент увидит выбранные названия работ и фото. Цены остаются внутренней информацией.",
    },
}
for _lang, _values in T_EXTRA.items():
    T.setdefault(_lang, {}).update(_values)

# Additional workflow copy.
_WORKFLOW_TRANSLATIONS = {
    "uz": {
        "Choose all repair works you actually completed. The customer will see the work names and quantities, but not prices.":"Haqiqatan bajargan barcha ishlarni tanlang. Mijoz ish nomlari va sonini ko‘radi, lekin narxlarni ko‘rmaydi.",
        "Search work…":"Ishni qidiring…", "All categories":"Barcha toifalar", "Quantity":"Soni",
        "Choose works":"Ishlarni tanlash", "Upload proof":"Dalil suratini yuklash", "Customer approves":"Mijoz tasdiqlaydi",
        "You approved this repair.":"Siz bu ta’mirni tasdiqladingiz.",
    },
    "uz-cyrl": {
        "Choose all repair works you actually completed. The customer will see the work names and quantities, but not prices.":"Ҳақиқатан бажарган барча ишларни танланг. Мижоз иш номлари ва сонини кўради, лекин нархларни кўрмайди.",
        "Search work…":"Ишни қидиринг…", "All categories":"Барча тоифалар", "Quantity":"Сони",
        "Choose works":"Ишларни танлаш", "Upload proof":"Далил суратини юклаш", "Customer approves":"Мижоз тасдиқлайди",
        "You approved this repair.":"Сиз бу таъмирни тасдиқладингиз.",
    },
    "ru": {
        "Choose all repair works you actually completed. The customer will see the work names and quantities, but not prices.":"Выберите все фактически выполненные работы. Клиент увидит названия и количество, но не цены.",
        "Search work…":"Поиск работы…", "All categories":"Все категории", "Quantity":"Количество",
        "Choose works":"Выбрать работы", "Upload proof":"Загрузить фото", "Customer approves":"Клиент подтверждает",
        "You approved this repair.":"Вы подтвердили этот ремонт.",
    },
}
for _lang, _values in _WORKFLOW_TRANSLATIONS.items():
    T.setdefault(_lang, {}).update(_values)


@register.filter
def tr(value):
    lang = (get_language() or 'en').lower()
    return T.get(lang, {}).get(str(value), str(value))


@register.filter
def work_name(value):
    lang = (get_language() or 'en').lower()
    return value.localized_name(lang) if value else ''

@register.filter
def dict_get(value, key):
    if not value:
        return ""
    try:
        return value.get(str(key), value.get(key, ""))
    except AttributeError:
        return ""

