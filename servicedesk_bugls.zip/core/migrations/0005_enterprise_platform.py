from django.db import migrations, models
import django.db.models.deletion


def backfill_primary_category(apps, schema_editor):
    Application = apps.get_model("core", "Application")
    for app in Application.objects.all().iterator():
        category = app.equipment_types.first()
        if category:
            app.equipment_type_id = category.pk
            app.save(update_fields=["equipment_type"])


def seed_rules(apps, schema_editor):
    Rule = apps.get_model("core", "SystemRule")
    defaults = [
        ("urgent_sla_minutes", "Urgent response target", "30", "Target first-response time for urgent requests."),
        ("max_active_jobs", "Recommended max active jobs", "5", "Dispatcher workload warning threshold per technician."),
        ("auto_refresh_seconds", "Dispatch board refresh", "30", "How often the dispatch board refreshes."),
    ]
    for key, label, value, description in defaults:
        Rule.objects.get_or_create(key=key, defaults={"label": label, "value": value, "description": description})


class Migration(migrations.Migration):
    dependencies = [("core", "0004_application_lifecycle_timestamps")]

    operations = [
        migrations.AddField(model_name="equipmenttype", name="active", field=models.BooleanField(default=True)),
        migrations.AddField(model_name="equipmenttype", name="color", field=models.CharField(default="violet", max_length=20)),
        migrations.AddField(model_name="department", name="active", field=models.BooleanField(default=True)),
        migrations.AddField(model_name="application", name="equipment_type", field=models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.PROTECT, related_name="applications", to="core.equipmenttype")),
        migrations.AddField(model_name="application", name="dispatcher_notes", field=models.TextField(blank=True, default="")),
        migrations.AddField(model_name="application", name="resolution_notes", field=models.TextField(blank=True, default="")),
        migrations.CreateModel(
            name="SystemRule",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("key", models.CharField(max_length=80, unique=True)),
                ("label", models.CharField(max_length=160)),
                ("value", models.CharField(max_length=200)),
                ("description", models.TextField(blank=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("updated_by", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, to="core.user")),
            ],
            options={"ordering": ["label"]},
        ),
        migrations.CreateModel(
            name="Notification",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("title", models.CharField(max_length=180)),
                ("body", models.CharField(blank=True, max_length=500)),
                ("read_at", models.DateTimeField(blank=True, null=True)),
                ("created_at", models.DateTimeField(auto_now_add=True, db_index=True)),
                ("application", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.CASCADE, related_name="notifications", to="core.application")),
                ("user", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="notifications", to="core.user")),
            ],
            options={"ordering": ["-created_at"]},
        ),
        migrations.AddIndex(model_name="user", index=models.Index(fields=["role"], name="core_user_role_idx")),
        migrations.AddIndex(model_name="application", index=models.Index(fields=["equipment_type", "status", "-created_at"], name="core_app_type_status_idx")),
        migrations.RemoveIndex(model_name="application", name="core_app_urgent_status_idx"),
        migrations.AddIndex(model_name="application", index=models.Index(fields=["is_urgent", "status", "-created_at"], name="core_app_urgent_status_idx")),
        migrations.AddIndex(model_name="applicationevent", index=models.Index(fields=["application", "-created_at"], name="core_event_app_created_idx")),
        migrations.AddIndex(model_name="notification", index=models.Index(fields=["user", "read_at", "-created_at"], name="core_note_user_read_idx")),
        migrations.RunPython(backfill_primary_category, migrations.RunPython.noop),
        migrations.RunPython(seed_rules, migrations.RunPython.noop),
    ]
