import re
from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.password_validation import validate_password
from django.core.validators import RegexValidator
from .models import User, Application, Department, EquipmentType, SystemRule, PriceListItem
from .phone_codes import local_digits, normalize_phone, split_phone


class PhoneWidget(forms.TextInput):
    input_type = "tel"

    def __init__(self, attrs=None):
        base = {
            "class": "phone-local-input",
            "placeholder": "(90) 123 - 45 - 67",
            "autocomplete": "tel-national",
            "inputmode": "numeric",
            "aria-label": "Uzbekistan phone number",
        }
        if attrs:
            base.update(attrs)
        super().__init__(base)

    def format_value(self, value):
        if not value:
            return ""
        _, local = split_phone(value)
        return format_uz_phone(local)


def format_uz_phone(value):
    """Format local digits exactly like the browser mask: (99) 123 - 45 - 67."""
    d = local_digits(value)[:9]
    if not d:
        return ""
    if len(d) <= 2:
        return f"({d}"
    if len(d) <= 5:
        return f"({d[:2]}) {d[2:]}"
    if len(d) <= 7:
        return f"({d[:2]}) {d[2:5]} - {d[5:]}"
    return f"({d[:2]}) {d[2:5]} - {d[5:7]} - {d[7:9]}"


class PhoneField(forms.CharField):
    """A fixed Uzbekistan (+998) phone field with a friendly input mask."""

    default_error_messages = {
        "invalid": "Enter a valid Uzbekistan phone number in the format (99) 123 - 11 - 22.",
    }

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("widget", PhoneWidget())
        kwargs.setdefault("required", True)
        super().__init__(*args, **kwargs)

    def prepare_value(self, value):
        return value

    def to_python(self, value):
        value = super().to_python(value)
        if not value:
            return ""
        digits = local_digits(value)
        if len(digits) != 9:
            raise forms.ValidationError(self.error_messages["invalid"], code="invalid")
        return normalize_phone(digits)

    def validate(self, value):
        super().validate(value)
        if value and value != normalize_phone(value):
            raise forms.ValidationError(self.error_messages["invalid"], code="invalid")


class PhoneLoginForm(AuthenticationForm):
    username = PhoneField(label="Phone number")
    password = forms.CharField(label="Password", widget=forms.PasswordInput)

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # AuthenticationForm injects maxlength=20 which truncates formatted/pasted numbers.
        self.fields["username"].widget.attrs.pop("maxlength", None)

    def clean(self):
        username = self.cleaned_data.get("username")
        password = self.cleaned_data.get("password")
        if username and password:
            user = User.objects.filter(phone_number=username).first()
            if user and not user.is_active and user.check_password(password):
                raise forms.ValidationError("This account is blocked. Contact an administrator.", code="inactive")
        return super().clean()


class CustomerRegistrationForm(forms.ModelForm):
    phone_number = PhoneField(label="Phone number")
    password1 = forms.CharField(label="Password", widget=forms.PasswordInput, help_text="Minimum 8 characters.")
    password2 = forms.CharField(label="Confirm password", widget=forms.PasswordInput)
    class Meta:
        model = User
        fields = ["phone_number", "full_name"]
    def clean_phone_number(self):
        phone = self.cleaned_data["phone_number"]
        if User.objects.filter(phone_number=phone).exists(): raise forms.ValidationError("An account with this phone number already exists.")
        return phone
    def clean(self):
        cleaned = super().clean(); p1, p2 = cleaned.get("password1"), cleaned.get("password2")
        if p1 and p2 and p1 != p2: self.add_error("password2", "Passwords do not match.")
        if p1:
            try: validate_password(p1, self.instance)
            except forms.ValidationError as exc: self.add_error("password1", exc)
        return cleaned
    def save(self, commit=True):
        user = super().save(commit=False); user.role = User.CUSTOMER; user.set_password(self.cleaned_data["password1"])
        if commit: user.save()
        return user


class StaffCreateForm(forms.ModelForm):
    phone_number = PhoneField(label="Phone number")
    password1 = forms.CharField(label="Password", widget=forms.PasswordInput, help_text="Minimum 8 characters.")
    password2 = forms.CharField(label="Confirm password", widget=forms.PasswordInput)
    specializations = forms.ModelMultipleChoiceField(queryset=EquipmentType.objects.filter(active=True), required=False, widget=forms.CheckboxSelectMultiple)
    role = forms.ChoiceField(choices=[(User.WORKER, "Worker"), (User.DISPATCHER, "Dispatcher")])
    class Meta:
        model = User
        fields = ["phone_number", "full_name", "role", "specializations"]
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["role"].widget.attrs["data-role-select"] = ""
    def clean_phone_number(self):
        phone = self.cleaned_data["phone_number"]
        if User.objects.filter(phone_number=phone).exists(): raise forms.ValidationError("An account with this phone number already exists.")
        return phone
    def clean(self):
        cleaned = super().clean(); p1, p2 = cleaned.get("password1"), cleaned.get("password2")
        if p1 and p2 and p1 != p2: self.add_error("password2", "Passwords do not match.")
        if p1:
            try: validate_password(p1, self.instance)
            except forms.ValidationError as exc: self.add_error("password1", exc)
        if cleaned.get("role") == User.WORKER and not cleaned.get("specializations"):
            self.add_error("specializations", "Choose at least one repair specialization for a worker.")
        if cleaned.get("role") != User.WORKER:
            cleaned["specializations"] = EquipmentType.objects.none()
        return cleaned
    def save(self, commit=True):
        user = super().save(commit=False); user.set_password(self.cleaned_data["password1"])
        if commit:
            user.save(); user.specializations.set(self.cleaned_data.get("specializations", []))
        return user


class StaffEditForm(forms.ModelForm):
    phone_number = PhoneField(label="Phone number")
    specializations = forms.ModelMultipleChoiceField(queryset=EquipmentType.objects.filter(active=True), required=False, widget=forms.CheckboxSelectMultiple)
    role = forms.ChoiceField(choices=[(User.WORKER, "Worker"), (User.DISPATCHER, "Dispatcher")])
    class Meta:
        model = User
        fields = ["phone_number", "full_name", "role", "is_active", "specializations"]
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["role"].widget.attrs["data-role-select"] = ""
        self.fields["role"].initial = self.instance.role
        if self.instance.is_customer: self.fields["role"].choices = [(User.CUSTOMER, "Customer")]
    def clean_phone_number(self):
        phone = self.cleaned_data["phone_number"]
        if User.objects.filter(phone_number=phone).exclude(pk=self.instance.pk).exists(): raise forms.ValidationError("That phone number is already in use.")
        return phone
    def clean(self):
        cleaned = super().clean()
        if cleaned.get("role") == User.WORKER and not cleaned.get("specializations"): self.add_error("specializations", "A worker must have at least one specialization.")
        if cleaned.get("role") != User.WORKER:
            cleaned["specializations"] = EquipmentType.objects.none()
        return cleaned
    def save(self, commit=True):
        user = super().save(commit=commit)
        if commit: user.specializations.set(self.cleaned_data.get("specializations", []))
        return user


class PasswordResetForm(forms.Form):
    new_password1 = forms.CharField(label="New password", widget=forms.PasswordInput)
    new_password2 = forms.CharField(label="Confirm new password", widget=forms.PasswordInput)
    def clean(self):
        cleaned = super().clean(); p1, p2 = cleaned.get("new_password1"), cleaned.get("new_password2")
        if p1 and p2 and p1 != p2: self.add_error("new_password2", "Passwords do not match.")
        if p1:
            try: validate_password(p1)
            except forms.ValidationError as exc: self.add_error("new_password1", exc)
        return cleaned


class ApplicationForm(forms.ModelForm):
    inner_phone = forms.CharField(max_length=4, validators=[RegexValidator(r"^\d{4}$", "Enter exactly 4 digits.")], widget=forms.TextInput(attrs={"placeholder": "1234", "maxlength": "4", "inputmode": "numeric"}))
    equipment_type = forms.ModelChoiceField(queryset=EquipmentType.objects.filter(active=True), empty_label=None, widget=forms.RadioSelect)
    department = forms.ModelChoiceField(queryset=Department.objects.filter(active=True), empty_label="Select department")
    class Meta:
        model = Application
        fields = ["customer_name", "department", "room", "equipment_type", "description", "inner_phone"]
        widgets = {
            "customer_name": forms.TextInput(attrs={"placeholder": "Person requesting service"}),
            "room": forms.TextInput(attrs={"placeholder": "Room / location"}),
            "description": forms.Textarea(attrs={"placeholder": "Describe the problem clearly…", "rows": 5}),
        }


class DispatcherNoteForm(forms.ModelForm):
    class Meta:
        model = Application
        fields = ["dispatcher_notes"]
        widgets = {"dispatcher_notes": forms.Textarea(attrs={"rows": 3, "placeholder": "Internal dispatch notes…"})}


class ResolutionForm(forms.ModelForm):
    class Meta:
        model = Application
        fields = ["resolution_notes"]
        widgets = {"resolution_notes": forms.Textarea(attrs={"rows": 3, "placeholder": "What was repaired / done?"})}


class SystemRuleForm(forms.ModelForm):
    class Meta:
        model = SystemRule
        fields = ["label", "value", "description"]

class WorkerCompletionForm(forms.Form):
    """Technician closes a repair by choosing every work actually performed and uploading proof."""
    works = forms.ModelMultipleChoiceField(
        queryset=PriceListItem.objects.filter(active=True).select_related("price_category"),
        required=True,
        widget=forms.CheckboxSelectMultiple,
        error_messages={"required": "Choose at least one work you completed."},
    )
    resolution_notes = forms.CharField(
        required=True,
        min_length=5,
        label="Completion note",
        widget=forms.Textarea(attrs={"rows": 4, "placeholder": "Briefly describe what you repaired or changed."}),
    )
    completion_photo = forms.ImageField(
        required=True,
        label="Proof photo",
        help_text="Take a clear photo of the completed work. Maximum 10 MB.",
    )

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields["completion_photo"].widget.attrs.update({
            "accept": "image/*",
            "capture": "environment",
        })

    def clean(self):
        cleaned = super().clean()
        works = cleaned.get("works")
        if works:
            quantities = {}
            for item in works:
                raw = self.data.get(f"qty_{item.pk}", "1")
                try:
                    quantity = int(raw)
                except (TypeError, ValueError):
                    self.add_error("works", f"Enter a valid quantity for {item.name_en}.")
                    continue
                if quantity < 1 or quantity > 9999:
                    self.add_error("works", f"Quantity for {item.name_en} must be between 1 and 9999.")
                    continue
                quantities[item.pk] = quantity
            if not self.errors.get("works"):
                cleaned["quantities"] = quantities
        return cleaned

    def clean_completion_photo(self):
        photo = self.cleaned_data["completion_photo"]
        if photo and photo.size > 10 * 1024 * 1024:
            raise forms.ValidationError("The photo must be 10 MB or smaller.")
        return photo


class CustomerApprovalForm(forms.Form):
    note = forms.CharField(
        required=False,
        label="Approval note",
        widget=forms.Textarea(attrs={"rows": 3, "placeholder": "Optional note about the completed work."}),
    )


class CustomerCorrectionForm(forms.Form):
    note = forms.CharField(
        required=True,
        min_length=3,
        label="What needs correction?",
        widget=forms.Textarea(attrs={"rows": 3, "placeholder": "Tell the technician what is still missing or needs fixing."}),
    )
