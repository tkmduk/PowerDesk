(() => {
  'use strict';

  /* ---------- Uzbekistan phone mask: (90) 123 - 45 - 67 ----------
     The mask edits DIGITS, not characters, so separators can never trap the caret.
     Rules mirror core/phone_codes.py:
       * "998" is a country code only with 12+ digits (99 8xx xx xx is a valid local number)
       * a leading "8" is a trunk prefix only when exactly 10 digits are present
     These prefixes are stripped only for paste/autofill, never while typing. */

  const digitsOnly = (v) => String(v || '').replace(/\D/g, '');

  function normalizeDigits(raw) {
    let d = digitsOnly(raw);
    if (d.length >= 12 && d.startsWith('998')) d = d.slice(3);
    else if (d.length === 10 && d.startsWith('8')) d = d.slice(1);
    else if (/^\s*\+/.test(String(raw)) && d.startsWith('998')) d = d.slice(3);
    return d.slice(0, 9);
  }

  function formatPhone(d) {
    if (!d) return '';
    if (d.length <= 2) return `(${d}`;
    if (d.length <= 5) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
    if (d.length <= 7) return `(${d.slice(0, 2)}) ${d.slice(2, 5)} - ${d.slice(5)}`;
    return `(${d.slice(0, 2)}) ${d.slice(2, 5)} - ${d.slice(5, 7)} - ${d.slice(7, 9)}`;
  }

  // Caret position directly after the n-th digit of a formatted value.
  function caretAfterDigit(formatted, n) {
    if (n <= 0) return formatted ? 1 : 0; // after "("
    let seen = 0;
    for (let i = 0; i < formatted.length; i++) {
      if (/\d/.test(formatted[i]) && ++seen === n) return i + 1;
    }
    return formatted.length;
  }

  function bindPhone(input) {
    if (input.dataset.phoneBound) return;
    input.dataset.phoneBound = '1';
    input.removeAttribute('maxlength'); // formatted value is longer than the digit count

    const render = (digits, caretDigits) => {
      input.value = formatPhone(digits);
      const pos = caretAfterDigit(input.value, Math.min(caretDigits, digits.length));
      try { input.setSelectionRange(pos, pos); } catch (_) { /* unsupported type */ }
    };

    // Backspace/Delete remove the adjacent DIGIT, skipping separators like ") " and " - ".
    input.addEventListener('beforeinput', (e) => {
      const t = e.inputType;
      if (t !== 'deleteContentBackward' && t !== 'deleteContentForward') return;
      if (input.selectionStart !== input.selectionEnd) return; // selection: default behaviour
      e.preventDefault();
      const digits = digitsOnly(input.value);
      const before = digitsOnly(input.value.slice(0, input.selectionStart)).length;
      const idx = t === 'deleteContentBackward' ? before - 1 : before;
      if (idx < 0 || idx >= digits.length) return;
      render(digits.slice(0, idx) + digits.slice(idx + 1), idx);
    });

    input.addEventListener('input', (e) => {
      const kind = e.inputType || '';
      const typing = kind === 'insertText' || kind.startsWith('delete');
      const raw = input.value;
      let digits;
      let caretDigits;
      if (typing) {
        digits = digitsOnly(raw).slice(0, 9);
        caretDigits = digitsOnly(raw.slice(0, input.selectionStart ?? raw.length)).length;
      } else { // paste, drop, autofill, undo: normalise country/trunk prefixes
        digits = normalizeDigits(raw);
        caretDigits = digits.length;
      }
      render(digits, caretDigits);
    });

    if (input.value) render(normalizeDigits(input.value), 99);
  }

  function initPhones() {
    document.querySelectorAll('.phone-field input, input.phone-local-input').forEach(bindPhone);
  }

  /* ---------- Password show/hide ---------- */
  function initPasswordToggles() {
    document.querySelectorAll('[data-password-toggle]').forEach((button) => {
      button.addEventListener('click', () => {
        const input = document.getElementById(button.dataset.passwordToggle);
        if (!input) return;
        const show = input.type === 'password';
        input.type = show ? 'text' : 'password';
        button.textContent = show ? (button.dataset.hideLabel || 'Hide') : (button.dataset.showLabel || 'Show');
        button.setAttribute('aria-label', show ? (button.dataset.hideLabel || 'Hide password') : (button.dataset.showLabel || 'Show password'));
      });
    });
  }

  /* ---------- Staff form: specializations apply to workers only ---------- */
  function initRoleToggle() {
    document.querySelectorAll('[data-role-select]').forEach((select) => {
      const form = select.closest('form');
      const box = form && form.querySelector('[data-spec-box]');
      if (!box) return;
      const sync = () => { box.hidden = select.value !== 'worker'; };
      select.addEventListener('change', sync);
      sync();
    });
  }

  /* ---------- Prevent double submit; recover when returning via back button ---------- */
  function resetBusy(form) {
    const button = form.querySelector('button.is-loading');
    if (!button) return;
    button.disabled = false;
    button.classList.remove('is-loading');
    if (button.dataset.originalHtml) button.innerHTML = button.dataset.originalHtml;
  }

  function initForms() {
    document.querySelectorAll('form[data-busy-form]').forEach((form) => {
      form.addEventListener('submit', () => {
        const button = form.querySelector('button[type="submit"], button:not([type])');
        if (!button || button.disabled) return;
        button.dataset.originalHtml = button.innerHTML;
        // Defer so the browser still serialises the submit button / runs validation first.
        window.setTimeout(() => {
          button.disabled = true;
          button.classList.add('is-loading');
          button.textContent = 'Please wait…';
        }, 0);
      });
    });
    window.addEventListener('pageshow', (e) => {
      if (e.persisted) document.querySelectorAll('form[data-busy-form]').forEach(resetBusy);
    });
  }

  document.addEventListener('DOMContentLoaded', () => {
    initPhones();
    initPasswordToggles();
    initRoleToggle();
    initForms();
  });
})();

// Small form/status phrases that contain template-rendered fields are translated here too.
(function(){
  const lang=document.documentElement.lang;
  const extra={
    uz:{'Full name':'To‘liq ism','Confirm password':'Parolni tasdiqlang','Minimum 8 characters.':'Kamida 8 ta belgi.','Format: (99) 123 - 11 - 22':'Format: (99) 123 - 11 - 22','Format: (99) 123 - 45 - 67':'Format: (99) 123 - 45 - 67','Already have an account?':'Hisobingiz bormi?','Dispatch will assign the correct specialist.':'Dispetcher mos mutaxassisni biriktiradi.','Save note':'Izohni saqlash','No requests match':'Mos so‘rovlar topilmadi','Try a different filter.':'Boshqa filtrni sinab ko‘ring.','Users page':'Foydalanuvchilar sahifasi','Technician assigned ·':'Texnik biriktirildi ·','NEW CUSTOMER':'YANGI MIJOZ','ROLE-AWARE ACCESS':'ROL ASOSIDAGI KIRISH','STAFF ACCESS':'XODIMLAR KIRISHI','TOTAL SYSTEM VISIBILITY':'TIZIMNI TO‘LIQ KO‘RISH','NEED A TECHNICIAN?':'TEXNIK KERAKMI?','URGENT':'SHOSHILINCH'},
    'uz-cyrl':{'Full name':'Тўлиқ исм','Confirm password':'Паролни тасдиқланг','Minimum 8 characters.':'Камида 8 та белги.','Already have an account?':'Ҳисобингиз борми?','Dispatch will assign the correct specialist.':'Диспетчер мос мутахассисни бириктиради.','Save note':'Изоҳни сақлаш','No requests match':'Мос сўровлар топилмади','Try a different filter.':'Бошқа филтрни синаб кўринг.','Users page':'Фойдаланувчилар саҳифаси','Technician assigned ·':'Техник бириктирилди ·','NEW CUSTOMER':'ЯНГИ МИЖОЗ','ROLE-AWARE ACCESS':'РОЛ АСОСИДАГИ КИРИШ','STAFF ACCESS':'ХОДИМЛАР КИРИШИ','TOTAL SYSTEM VISIBILITY':'ТИЗИМНИ ТЎЛИҚ КЎРИШ','NEED A TECHNICIAN?':'ТЕХНИК КЕРАКМИ?','URGENT':'ШОШИЛИНЧ'},
    ru:{'Full name':'Полное имя','Confirm password':'Подтвердите пароль','Minimum 8 characters.':'Минимум 8 символов.','Already have an account?':'Уже есть аккаунт?','Dispatch will assign the correct specialist.':'Диспетчер назначит подходящего специалиста.','Save note':'Сохранить заметку','No requests match':'Подходящих заявок нет','Try a different filter.':'Попробуйте другой фильтр.','Users page':'Страница пользователей','Technician assigned ·':'Техник назначен ·','NEW CUSTOMER':'НОВЫЙ КЛИЕНТ','ROLE-AWARE ACCESS':'ДОСТУП ПО РОЛИ','STAFF ACCESS':'ДОСТУП СОТРУДНИКОВ','TOTAL SYSTEM VISIBILITY':'ПОЛНАЯ ВИДИМОСТЬ СИСТЕМЫ','NEED A TECHNICIAN?':'НУЖЕН ТЕХНИК?','URGENT':'СРОЧНО'}
  };
  if(window.SD_TRANSLATIONS?.[lang]) Object.assign(window.SD_TRANSLATIONS[lang],extra[lang]||{});
  if(lang!=='en' && document.title) document.title=(extra[lang]||{})[document.title] || document.title;
})();

/* Public UI translations. The server still owns all business/user-entered content. */
(function(){
  const lang = document.documentElement.lang || 'en';
  if (lang === 'en') return;
  const dict = window.SD_TRANSLATIONS?.[lang];
  if (!dict) return;
  const translateNode = node => {
    if (node.nodeType !== Node.TEXT_NODE) return;
    const value = node.nodeValue.trim();
    if (!value || !dict[value]) return;
    node.nodeValue = node.nodeValue.replace(value, dict[value]);
  };
  const walk = root => {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT);
    const nodes=[]; while(walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(translateNode);
    root.querySelectorAll?.('[placeholder],[title],[aria-label]').forEach(el=>['placeholder','title','aria-label'].forEach(a=>{if(dict[el.getAttribute(a)]) el.setAttribute(a,dict[el.getAttribute(a)]);}));
  };
  walk(document.body);
})();
