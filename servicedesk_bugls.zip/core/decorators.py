"""Role-based access decorators."""

from functools import wraps
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden


def role_required(*roles):
    """Decorator that checks the user has one of the specified roles."""

    def decorator(view_func):
        @wraps(view_func)
        @login_required
        def wrapper(request, *args, **kwargs):
            if request.user.role not in roles:
                return HttpResponseForbidden("You do not have permission to access this page.")
            return view_func(request, *args, **kwargs)

        return wrapper

    return decorator


def customer_required(view_func):
    return role_required("customer")(view_func)


def worker_required(view_func):
    return role_required("worker")(view_func)


def dispatcher_required(view_func):
    return role_required("dispatcher")(view_func)


def superadmin_required(view_func):
    return role_required("superadmin")(view_func)


def dispatcher_or_superadmin(view_func):
    return role_required("dispatcher", "superadmin")(view_func)
