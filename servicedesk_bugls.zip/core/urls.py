from django.urls import path
from django.views.generic import RedirectView
from . import views
app_name = "core"
urlpatterns = [
    path("", RedirectView.as_view(url="/dashboard/", permanent=False), name="root"),
    path("login/", views.login_view, name="login"), path("register/", views.customer_register, name="register"),
    path("logout/", views.logout_view, name="logout"), path("dashboard/", views.dashboard, name="dashboard"),
    path("customer/", views.customer_dashboard, name="customer_dashboard"), path("customer/apps/<int:pk>/approve/", views.customer_approve, name="customer_approve"), path("customer/apps/<int:pk>/correction/", views.customer_request_correction, name="customer_request_correction"),
    path("worker/", views.worker_dashboard, name="worker_dashboard"), path("worker/apps/<int:pk>/claim/", views.worker_claim, name="worker_claim"), path("worker/apps/<int:pk>/start/", views.worker_start, name="worker_start"), path("worker/apps/<int:pk>/resume/", views.worker_resume_correction, name="worker_resume_correction"), path("worker/apps/<int:pk>/complete/", views.worker_complete, name="worker_complete"),
    path("dispatcher/", views.dispatcher_dashboard, name="dispatcher_dashboard"), path("dispatcher/apps/<int:pk>/assign/", views.assign_worker, name="assign_worker"), path("dispatcher/apps/<int:pk>/priority/", views.toggle_priority, name="toggle_priority"), path("dispatcher/apps/<int:pk>/note/", views.dispatcher_note, name="dispatcher_note"),
    path("superadmin/", views.superadmin_dashboard, name="superadmin_dashboard"), path("superadmin/apps/<int:pk>/report/", views.superadmin_application_detail, name="superadmin_application_detail"), path("superadmin/users/create/", views.superadmin_user_create, name="superadmin_user_create"), path("superadmin/users/<int:pk>/edit/", views.superadmin_user_edit, name="superadmin_user_edit"), path("superadmin/users/<int:pk>/reset-password/", views.superadmin_reset_password, name="superadmin_reset_password"), path("superadmin/users/<int:pk>/block/", views.superadmin_toggle_block, name="superadmin_toggle_block"), path("superadmin/users/<int:pk>/delete/", views.superadmin_delete_user, name="superadmin_delete_user"), path("superadmin/workers/stats/", views.superadmin_worker_stats, name="superadmin_worker_stats"), path("superadmin/rules/", views.superadmin_rule, name="superadmin_rule_create"), path("superadmin/rules/<int:pk>/", views.superadmin_rule, name="superadmin_rule"),
]
